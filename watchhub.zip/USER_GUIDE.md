# WatchHub - User Guide

## Getting Started

### Creating an Account
1. Launch the WatchHub app
2. Tap **Sign Up** on the login screen
3. Enter your name, email, and password (minimum 6 characters)
4. Tap **Sign Up** to create your account
5. You will be automatically logged in

### Logging In
1. Enter your registered email and password
2. Tap **Sign In**
3. If you forget your password, tap **Forgot Password** to receive a reset link

### Onboarding Screens
On first launch, you'll see three onboarding screens explaining the app's features. Swipe left to navigate through them, or tap **Skip** to go directly to login.

---

## Browsing Watches

### Home Screen
- The home screen displays **Popular Watches**, **New Arrivals**, and **All Watches**
- Tap category chips at the top to filter by watch type
- Tap **See All** on any section to view the full search screen

### Search
- Tap the **Search** tab in the bottom navigation bar
- Type a watch name, brand, or keyword in the search bar
- Use the **sort dropdown** to sort by price, rating, or popularity
- Tap the **filter icon** to filter by brand, type, and price range

### Product Details
- Tap any watch card to view its full details
- View high-resolution images - tap an image to zoom in
- Read the description, specifications, and customer reviews
- Check stock availability

---

## Shopping Cart

### Adding Items
- On a product detail page, tap **Add to Cart**
- The cart badge in the top-right corner shows your item count

### Managing Cart
- Go to the **Cart** tab to view all items
- Use **+** and **-** buttons to adjust quantities
- Tap the **delete icon** to remove an item
- The total price updates automatically

### Checkout
- Tap **Checkout** in the cart screen
- Enter your shipping address
- Confirm the order
- The order will appear in your Order History

---

## Wishlist

- Tap the **heart icon** on any watch card or product page to add it to your wishlist
- View all wishlisted items from your Profile
- Tap a wishlist item to view its product details and add it to the cart

---

## Orders & Tracking

### Order History
- Go to **Profile > Order History** to view all your orders
- Each order shows its status: Pending, Confirmed, Shipped, Delivered, or Cancelled
- Tap an order to expand it and see item details

### Track Order
- Go to **Profile > Track Order** to see only active orders (not yet delivered or cancelled)
- View tracking numbers for shipped orders

---

## Reviews & Ratings

### Writing a Review
- On a product detail page, tap **Write a Review**
- Select a star rating (1-5)
- Write your comments
- Tap **Submit**

### Sorting Reviews
- Use the dropdown above the reviews section to sort by:
  - **Most Recent** - newest reviews first
  - **Highest Rated** - best reviews first
  - **Lowest Rated** - critical reviews first
  - **Most Helpful** - reviews with the most helpful votes

---

## Profile

### Editing Profile
- Tap the **camera icon** on your profile avatar to change your profile picture
- Your name and email are displayed at the top

### Admin Panel
If you have admin privileges, tap **Admin Panel** in the Profile menu to manage:
- Products (add, edit, delete watches)
- Users (manage accounts, grant admin access)
- Orders (update status, add tracking numbers)
- Reviews (moderate and delete reviews)

---

## Support

### Live Chat
- Tap **Live Chat** to start a chat with the support team
- Available Mon-Fri, 9AM-6PM EST

### Email
- Tap **Email Us** to copy the support email address
- Email us at support@watchhub.com

### Phone
- Tap **Call Us** to copy the support phone number

### FAQ
- Browse frequently asked questions and answers

### Report an Issue
- Scroll down on the Support screen
- Select a category (Bug Report, Feature Request, Account Issue, etc.)
- Enter a title and detailed description
- Tap **Submit Report**
- Our team will review and respond

---

## Tips

- Pull down on any list to **refresh** the content
- Use the bottom navigation bar to quickly switch between Home, Search, Cart, and Profile
- Watch images are loaded from the internet - an internet connection is required
