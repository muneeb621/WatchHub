# WatchHub - Developer Guide

## Project Overview

WatchHub is a premium watch shopping mobile app built with Flutter. It features:
- Flutter frontend with Firebase integration and mock data fallback
- Express.js REST API server with JWT authentication
- HTML/CSS/JS admin panel
- In-memory data store (server) with Firebase optional (app)

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Flutter 3.x, Dart |
| State Management | Provider |
| Backend | Node.js, Express.js |
| Auth | JWT (jsonwebtoken) |
| Database | Firebase Firestore / In-memory mock data |
| Admin Panel | Bootstrap 5, Vanilla JS |
| Image Loading | cached_network_image, photo_view |

---

## Project Structure

```
watchhub/
├── lib/                    # Flutter app source
│   ├── config/             # Theme, routes, constants
│   ├── models/             # Data models (Watch, User, Order, etc.)
│   ├── providers/          # State management (ChangeNotifier)
│   ├── screens/            # UI screens
│   │   ├── admin/          # Admin dashboard & management screens
│   │   ├── auth/           # Login, signup, forgot password, onboarding
│   │   ├── cart/           # Shopping cart
│   │   ├── home/           # Home screen with tabs
│   │   ├── product/        # Product detail with reviews
│   │   ├── profile/        # User profile & order history
│   │   ├── search/         # Search & filter
│   │   ├── support/        # Support, FAQ, feedback
│   │   └── wishlist/       # Wishlist screen
│   ├── services/           # API service, auth service, Firebase service
│   └── widgets/            # Reusable widgets (WatchCard, ShimmerLoading, etc.)
├── server/                 # Express.js backend
│   ├── middleware/          # JWT auth middleware
│   ├── routes/             # API route handlers
│   ├── data/               # Seed data
│   └── server.js           # Entry point
├── admin/                  # Static HTML admin panel
├── admin-panel/            # (Unused) Next.js starter template
├── assets/images/          # Placeholder for local images
└── test/                   # Flutter tests
```

---

## Setup & Installation

### Prerequisites
- Flutter SDK 3.12+
- Node.js 18+
- Dart SDK 3.12+

### Running the Flutter App
```bash
# Install dependencies
flutter pub get

# Run on device/emulator
flutter run

# Build for production
flutter build apk    # Android
flutter build ios    # iOS
flutter build web   # Web
```

### Running the Express Server
```bash
cd server
npm install
node server.js
# Server runs on http://localhost:3000
# Admin panel at http://localhost:3000/admin
```

---

## Architecture

### Dual Data Source Pattern
The app supports two data sources, selected automatically:
1. **Firebase Firestore** - Used when Firebase is initialized successfully
2. **In-memory Mock Data** - Fallback when Firebase is unavailable

This is controlled by `FirebaseService.isFirestoreAvailable` in `lib/services/firebase_service.dart`.

### Auth Flow
1. User logs in via `AuthProvider.login()`
2. `AuthService` attempts Firebase authentication (3s timeout)
3. If Firebase fails, falls back to SharedPreferences-based mock auth
4. Admin check: email `admin@watchhub.com` is automatically granted admin role
5. JWT tokens are used for server API calls

### State Management
Provider pattern is used throughout:
- `AuthProvider` - Authentication state
- `WatchProvider` - Watch listings, filters, search
- `CartProvider` - Cart with SharedPreferences persistence
- `WishlistProvider` - Wishlist with persistence
- `ReviewProvider` - Reviews by watch

---

## API Endpoints (Express Server)

All endpoints are prefixed with `/api`.

### Auth
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| POST | `/api/auth/login` | Login, returns JWT | No |
| POST | `/api/auth/signup` | Create account | No |
| POST | `/api/auth/reset-password` | Password reset | No |

### Watches
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/api/watches` | List watches (filter, sort, search) | No |
| GET | `/api/watches/popular` | Popular watches | No |
| GET | `/api/watches/new-arrivals` | New arrivals | No |
| GET | `/api/watches/:id` | Single watch | No |
| POST | `/api/watches` | Create watch | Admin |
| PUT | `/api/watches/:id` | Update watch | Admin |
| DELETE | `/api/watches/:id` | Delete watch | Admin |

### Orders
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/api/orders` | List orders (filter by userId) | JWT |
| POST | `/api/orders` | Create order | JWT |
| PUT | `/api/orders/:id/status` | Update status | Admin |
| PUT | `/api/orders/:id/tracking` | Update tracking | Admin |

### Users
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/api/users` | List users | Admin |
| POST | `/api/users` | Create user | Admin |
| PUT | `/api/users/:id` | Update user | Admin |
| DELETE | `/api/users/:id` | Delete user | Admin |

### Reviews
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/api/reviews` | List reviews (filter by watchId) | JWT |
| POST | `/api/reviews` | Create review | JWT |
| DELETE | `/api/reviews/:id` | Delete review | Admin |

### Categories
| Method | Endpoint | Description | Auth |
|---|---|---|---|
| GET | `/api/categories` | List categories | No |

---

## Authentication Middleware

Located in `server/middleware/auth.js`:

- **`authMiddleware`** - Verifies Bearer JWT token, sets `req.user`
- **`adminMiddleware`** - Checks `req.user.isAdmin === true`

All admin write operations require both middlewares chained:
```js
router.post('/', authMiddleware, adminMiddleware, handler);
```

---

## Key Implementations

### Models
All models are in `lib/models/` with `fromMap()`/`toMap()` serialization:
- `Watch` - Product with price, stock, images, specs
- `User` - Account info, admin flag, shipping addresses
- `Order` - Items, status (enum), tracking, shipping
- `Review` - Rating, comment, helpful count
- `CartItem` - Watch reference, quantity, computed total
- `Category` - Name and image
- `FeedbackItem` - Issue reports from support screen

### Services
- **`ApiService`** (singleton) - Central data access layer, Firebase + mock fallback
- **`AuthService`** - Firebase auth with mock backup using SharedPreferences
- **`FirebaseService`** - Firebase initialization with health check
- **`ImageService`** - Camera/gallery image picker

### Shimmer Loading
Custom shimmer widget in `lib/widgets/shimmer_loading.dart` using `ShaderMask` and `AnimationController`. Used in Home and Search screens during data loading.

---

## Testing

```bash
# Run all tests
flutter test

# Test files
test/models_test.dart     # Model serialization round-trip tests
test/widget_test.dart     # Widget rendering test
```

---

## Admin Panel

Two admin panels exist:
1. **Flutter Admin** - In-app admin via `Profile > Admin Panel` (routes `/admin*`)
2. **HTML Admin Panel** - Served from `admin/index.html` at `http://localhost:3000/admin`

Default admin credentials: `admin@watchhub.com` / `admin123`

---

## Common Issues

### Server admin routes return 403
Ensure `authMiddleware` is chained before `adminMiddleware`. See `server/routes/watches.js`.

### App falls back to mock data
Firebase initialization has a 2-second timeout. If Firebase is slow or unavailable, the app uses mock data. Check the console for Firebase logs.

### Images not loading
All product images are loaded from Unsplash URLs. An internet connection is required. Error fallback shows a watch icon.

---

## Extending the App

### Adding a New Model
1. Create a new file in `lib/models/`
2. Add `fromMap()` and `toMap()` methods
3. Add CRUD methods in `ApiService`
4. Create a Provider if needed
5. Add routes in `config/routes.dart`

### Adding a New Screen
1. Create the screen file in the appropriate `lib/screens/` subdirectory
2. Add a route constant in `AppRoutes`
3. Register the route in `AppRoutes.routes` map
4. Add to `_protectedRoutes` if authentication is required
