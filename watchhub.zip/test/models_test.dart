import 'package:flutter_test/flutter_test.dart';
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/models/user.dart';
import 'package:watchhub/models/cart_item.dart';
import 'package:watchhub/models/review.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/models/category.dart';

void main() {
  group('Watch', () {
    test('toMap and fromMap round-trip', () {
      final watch = Watch(
        id: '1', name: 'Test Watch', brand: 'TestBrand',
        type: 'Diver', description: 'A test watch',
        price: 500, originalPrice: 600, rating: 4.5,
        reviewCount: 100, stock: 10,
        images: ['https://example.com/image.jpg'],
        specifications: ['Water resistant'],
        isPopular: true, isNewArrival: false, discountTag: '10% OFF',
      );
      final map = watch.toMap();
      final restored = Watch.fromMap({...map, 'id': '1'});
      expect(restored.id, watch.id);
      expect(restored.name, watch.name);
      expect(restored.brand, watch.brand);
      expect(restored.price, watch.price);
      expect(restored.discountPercentage, 17);
      expect(restored.inStock, true);
    });
  });

  group('User', () {
    test('toMap and fromMap round-trip with createdAt', () {
      final now = DateTime(2024, 1, 15);
      final user = User(
        id: 'u1', email: 'test@test.com', name: 'Tester',
        phone: '+123', avatarUrl: null,
        shippingAddresses: ['123 Main St'],
        createdAt: now, isAdmin: false,
      );
      final map = user.toMap();
      final restored = User.fromMap(map);
      expect(restored.id, user.id);
      expect(restored.email, user.email);
      expect(restored.createdAt.toIso8601String(), '2024-01-15T00:00:00.000');
      expect(restored.shippingAddresses, ['123 Main St']);
    });

    test('copyWith updates fields', () {
      final user = User(id: 'u1', email: 'a@b.com', name: 'A');
      final updated = user.copyWith(name: 'B', isAdmin: true);
      expect(updated.name, 'B');
      expect(updated.isAdmin, true);
      expect(updated.id, 'u1');
    });
  });

  group('CartItem', () {
    test('totalPrice is price * quantity', () {
      final item = CartItem(id: 'c1', watchId: 'w1', watchName: 'Test', watchImage: '', price: 100, quantity: 3);
      expect(item.totalPrice, 300);
    });

    test('toMap and fromMap round-trip', () {
      final item = CartItem(id: 'c1', watchId: 'w1', watchName: 'Test', watchImage: 'img.jpg', price: 250, quantity: 2);
      final map = item.toMap();
      final restored = CartItem.fromMap(map);
      expect(restored.id, item.id);
      expect(restored.price, 250);
      expect(restored.quantity, 2);
    });
  });

  group('Review', () {
    test('toMap and fromMap round-trip with createdAt', () {
      final now = DateTime(2024, 3, 10);
      final review = Review(
        id: 'r1', watchId: 'w1', userId: 'u1',
        userName: 'John', rating: 4, comment: 'Great!',
        createdAt: now, helpfulCount: 5,
      );
      final map = review.toMap();
      final restored = Review.fromMap(map);
      expect(restored.comment, 'Great!');
      expect(restored.rating, 4.0);
      expect(restored.createdAt.toIso8601String(), '2024-03-10T00:00:00.000');
    });
  });

  group('Order', () {
    test('statusText returns correct string', () {
      expect(Order(id: 'o1', userId: 'u1', items: [], totalAmount: 0, shippingAddress: '', status: OrderStatus.pending).statusText, 'Pending');
      expect(Order(id: 'o1', userId: 'u1', items: [], totalAmount: 0, shippingAddress: '', status: OrderStatus.delivered).statusText, 'Delivered');
    });

    test('toMap and fromMap round-trip', () {
      final now = DateTime(2024, 5, 20);
      final order = Order(
        id: 'o1', userId: 'u1',
        items: [OrderItem(watchId: 'w1', watchName: 'Test Watch', watchImage: 'img.jpg', price: 500, quantity: 1)],
        totalAmount: 500, shippingAddress: 'Addr 1',
        status: OrderStatus.shipped, createdAt: now,
        trackingNumber: 'TRK123',
      );
      final map = order.toMap();
      final restored = Order.fromMap(map);
      expect(restored.id, 'o1');
      expect(restored.status, OrderStatus.shipped);
      expect(restored.trackingNumber, 'TRK123');
      expect(restored.items.length, 1);
    });
  });

  group('Category', () {
    test('toMap and fromMap round-trip', () {
      final cat = Category(id: 'c1', name: 'Luxury', imageUrl: 'img.jpg');
      final map = cat.toMap();
      final restored = Category.fromMap(map);
      expect(restored.name, 'Luxury');
    });
  });
}
