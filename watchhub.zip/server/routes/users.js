const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { users } = require('../data/seed');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();

router.use(authMiddleware);

router.get('/', adminMiddleware, (req, res) => {
  res.json(users.map(u => ({ ...u })));
});

router.post('/', adminMiddleware, (req, res) => {
  const { name, email, phone, avatarUrl, isAdmin } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'name and email required' });
  const newUser = {
    id: 'u' + uuidv4().slice(0, 8),
    name, email, phone: phone || null, avatarUrl: avatarUrl || null,
    shippingAddresses: [], isAdmin: isAdmin || false,
    createdAt: new Date().toISOString(),
  };
  users.push(newUser);
  res.status(201).json(newUser);
});

router.put('/:id', adminMiddleware, (req, res) => {
  const idx = users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  const existing = users[idx];
  const body = req.body;
  users[idx] = {
    ...existing,
    name: body.name ?? existing.name,
    email: body.email ?? existing.email,
    phone: body.phone !== undefined ? body.phone : existing.phone,
    avatarUrl: body.avatarUrl !== undefined ? body.avatarUrl : existing.avatarUrl,
    shippingAddresses: body.shippingAddresses ?? existing.shippingAddresses,
    isAdmin: body.isAdmin !== undefined ? body.isAdmin : existing.isAdmin,
  };
  res.json(users[idx]);
});

router.delete('/:id', adminMiddleware, (req, res) => {
  const idx = users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  users.splice(idx, 1);
  res.json({ message: 'User deleted' });
});

module.exports = router;