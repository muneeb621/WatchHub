const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { watches } = require('../data/seed');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  let result = [...watches];
  const { brand, type, sortBy, minPrice, maxPrice, searchQuery } = req.query;

  if (brand) result = result.filter(w => w.brand === brand);
  if (type) result = result.filter(w => w.type === type);
  if (minPrice) result = result.filter(w => w.price >= parseFloat(minPrice));
  if (maxPrice) result = result.filter(w => w.price <= parseFloat(maxPrice));
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    result = result.filter(w =>
      w.name.toLowerCase().includes(q) ||
      w.brand.toLowerCase().includes(q) ||
      w.description.toLowerCase().includes(q)
    );
  }
  if (sortBy) {
    switch (sortBy) {
      case 'Price: Low to High': result.sort((a, b) => a.price - b.price); break;
      case 'Price: High to Low': result.sort((a, b) => b.price - a.price); break;
      case 'Rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'Popularity': result.sort((a, b) => b.reviewCount - a.reviewCount); break;
    }
  }
  res.json(result);
});

router.get('/popular', (req, res) => {
  res.json(watches.filter(w => w.isPopular).slice(0, 10));
});

router.get('/new-arrivals', (req, res) => {
  res.json(watches.filter(w => w.isNewArrival).slice(0, 10));
});

router.get('/:id', (req, res) => {
  const watch = watches.find(w => w.id === req.params.id);
  if (!watch) return res.status(404).json({ error: 'Watch not found' });
  res.json(watch);
});

router.post('/', authMiddleware, adminMiddleware, (req, res) => {
  const { name, brand, type, description, price, originalPrice, stock, images, specifications, isPopular, isNewArrival, discountTag } = req.body;
  if (!name || !brand || !type || !description || price === undefined) {
    return res.status(400).json({ error: 'name, brand, type, description, price required' });
  }
  const newWatch = {
    id: uuidv4().slice(0, 8),
    name, brand, type, description,
    price: parseFloat(price),
    originalPrice: originalPrice ? parseFloat(originalPrice) : 0,
    rating: 0, reviewCount: 0,
    stock: stock ? parseInt(stock) : 0,
    images: images || ['https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800'],
    specifications: specifications || [],
    isPopular: isPopular || false,
    isNewArrival: isNewArrival || false,
    discountTag: discountTag || null,
  };
  watches.push(newWatch);
  res.status(201).json(newWatch);
});

router.put('/:id', authMiddleware, adminMiddleware, (req, res) => {
  const idx = watches.findIndex(w => w.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Watch not found' });
  const existing = watches[idx];
  const body = req.body;
  watches[idx] = {
    ...existing,
    name: body.name ?? existing.name,
    brand: body.brand ?? existing.brand,
    type: body.type ?? existing.type,
    description: body.description ?? existing.description,
    price: body.price !== undefined ? parseFloat(body.price) : existing.price,
    originalPrice: body.originalPrice !== undefined ? parseFloat(body.originalPrice) : existing.originalPrice,
    stock: body.stock !== undefined ? parseInt(body.stock) : existing.stock,
    images: body.images ?? existing.images,
    specifications: body.specifications ?? existing.specifications,
    isPopular: body.isPopular ?? existing.isPopular,
    isNewArrival: body.isNewArrival ?? existing.isNewArrival,
    discountTag: body.discountTag !== undefined ? body.discountTag : existing.discountTag,
  };
  res.json(watches[idx]);
});

router.delete('/:id', authMiddleware, adminMiddleware, (req, res) => {
  const idx = watches.findIndex(w => w.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Watch not found' });
  watches.splice(idx, 1);
  res.json({ message: 'Watch deleted' });
});

module.exports = router;