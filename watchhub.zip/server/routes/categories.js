const express = require('express');
const { categories } = require('../data/seed');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(categories);
});

module.exports = router;