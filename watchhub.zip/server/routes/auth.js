const express = require('express');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { users } = require('../data/seed');
const { JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }
  const user = users.find(u => u.email === email);
  if (!user) return res.status(401).json({ error: 'Invalid email or password' });
  const valid = user.password ? await bcrypt.compare(password, user.password) : password === (user.isAdmin ? 'admin123' : 'password123');
  if (!valid) return res.status(401).json({ error: 'Invalid email or password' });
  if (!user.password) user.password = await bcrypt.hash(user.isAdmin ? 'admin123' : 'password123', 10);
  const token = jwt.sign({ id: user.id, email: user.email, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '7d' });
  const { password: _, ...safe } = user;
  res.json({ user: safe, token });
});

router.post('/signup', async (req, res) => {
  const { email, name, password } = req.body;
  if (!email || !name || !password) {
    return res.status(400).json({ error: 'Email, name, and password required' });
  }
  if (users.find(u => u.email === email)) {
    return res.status(409).json({ error: 'Email already registered' });
  }
  const newUser = {
    id: 'u' + uuidv4().slice(0, 8),
    name, email, phone: null, avatarUrl: null,
    shippingAddresses: [], isAdmin: false,
    password: await bcrypt.hash(password, 10),
    createdAt: new Date().toISOString(),
  };
  users.push(newUser);
  const token = jwt.sign({ id: newUser.id, email: newUser.email, isAdmin: false }, JWT_SECRET, { expiresIn: '7d' });
  const { password: _, ...safe } = newUser;
  res.status(201).json({ user: safe, token });
});

router.post('/reset-password', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });
  const user = users.find(u => u.email === email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ message: 'Password reset email sent' });
});

module.exports = router;
