const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { orders } = require('../data/seed');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();

router.use(authMiddleware);

router.get('/', (req, res) => {
  const { userId } = req.query;
  let result = [...orders];
  if (userId) result = result.filter(o => o.userId === userId);
  res.json(result);
});

router.post('/', (req, res) => {
  const { userId, items, totalAmount, shippingAddress, status } = req.body;
  if (!userId || !items || !totalAmount || !shippingAddress) {
    return res.status(400).json({ error: 'userId, items, totalAmount, shippingAddress required' });
  }
  const newOrder = {
    id: 'ord' + uuidv4().slice(0, 8),
    userId, items, totalAmount: parseFloat(totalAmount),
    shippingAddress, status: status || 0,
    createdAt: new Date().toISOString(),
    deliveredAt: null, trackingNumber: null,
  };
  orders.unshift(newOrder);
  res.status(201).json(newOrder);
});

router.put('/:id/status', adminMiddleware, (req, res) => {
  const idx = orders.findIndex(o => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Order not found' });
  const { status } = req.body;
  if (status === undefined) return res.status(400).json({ error: 'status required' });
  orders[idx].status = parseInt(status);
  if (parseInt(status) === 3) orders[idx].deliveredAt = new Date().toISOString();
  res.json(orders[idx]);
});

router.put('/:id/tracking', adminMiddleware, (req, res) => {
  const idx = orders.findIndex(o => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Order not found' });
  const { trackingNumber } = req.body;
  if (!trackingNumber) return res.status(400).json({ error: 'trackingNumber required' });
  orders[idx].trackingNumber = trackingNumber;
  res.json(orders[idx]);
});

module.exports = router;