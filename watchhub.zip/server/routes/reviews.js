const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { reviews } = require('../data/seed');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

const router = express.Router();

router.use(authMiddleware);

router.get('/', (req, res) => {
  const { watchId } = req.query;
  let result = [...reviews];
  if (watchId) result = result.filter(r => r.watchId === watchId);
  result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(result);
});

router.post('/', (req, res) => {
  const { watchId, userId, userName, userAvatar, rating, comment } = req.body;
  if (!watchId || !userId || !userName || !rating || !comment) {
    return res.status(400).json({ error: 'watchId, userId, userName, rating, comment required' });
  }
  const newReview = {
    id: uuidv4().slice(0, 8),
    watchId, userId, userName,
    userAvatar: userAvatar || null,
    rating: parseFloat(rating),
    comment, helpfulCount: 0,
    createdAt: new Date().toISOString(),
  };
  reviews.unshift(newReview);
  res.status(201).json(newReview);
});

router.delete('/:id', adminMiddleware, (req, res) => {
  const idx = reviews.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Review not found' });
  reviews.splice(idx, 1);
  res.json({ message: 'Review deleted' });
});

module.exports = router;