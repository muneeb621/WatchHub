import 'dart:developer' as dev;

class Logger {
  static void info(String message) {
    dev.log('[INFO] $message', name: 'WatchHub');
  }

  static void warning(String message) {
    dev.log('[WARNING] $message', name: 'WatchHub');
  }

  static void error(String message, [Object? error, StackTrace? stack]) {
    dev.log('[ERROR] $message', name: 'WatchHub', error: error, stackTrace: stack);
  }

  static void debug(String message) {
    dev.log('[DEBUG] $message', name: 'WatchHub');
  }

  static void network(String method, String url, [int? statusCode]) {
    final status = statusCode != null ? ' -> $statusCode' : '';
    dev.log('[NETWORK] $method $url$status', name: 'WatchHub');
  }
}
