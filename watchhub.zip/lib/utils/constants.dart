class AppConfig {
  static const bool useFirebase = true;
  static const bool enableAnalytics = false;
  static const bool enableCrashlytics = false;
  static const bool enablePushNotifications = true;
  static const bool enableBiometric = true;
  static const bool enablePaymentGateway = true;

  static const String appVersion = '1.0.0';
  static const String supportEmail = 'support@watchhub.com';
  static const String supportPhone = '+1-555-WATCH-HUB';
  static const String websiteUrl = 'https://watchhub.com';

  static const int cartMaxItems = 50;
  static const int wishlistMaxItems = 100;
  static const int maxReviewLength = 500;
  static const int maxAddressesPerUser = 10;

  static const Duration cacheDuration = Duration(hours: 1);
  static const Duration searchDebounce = Duration(milliseconds: 300);
  static const Duration splashDuration = Duration(seconds: 2);
}
