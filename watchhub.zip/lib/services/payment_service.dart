import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:watchhub/config/constants.dart';
import 'package:watchhub/utils/logger.dart';

class PaymentResult {
  final bool success;
  final String? transactionId;
  final String? error;
  final String? receiptUrl;

  PaymentResult({
    required this.success,
    this.transactionId,
    this.error,
    this.receiptUrl,
  });
}

class PaymentService {
  static final PaymentService _instance = PaymentService._();
  factory PaymentService() => _instance;
  PaymentService._();

  Future<PaymentResult> processPayment({
    required double amount,
    required String cardNumber,
    required String expiryMonth,
    required String expiryYear,
    required String cvv,
    required String cardholderName,
    String? currency,
    String? description,
  }) async {
    try {
      if (amount <= 0) {
        return PaymentResult(success: false, error: 'Invalid amount');
      }
      final response = await http.post(
        Uri.parse('${AppConstants.apiBaseUrl}/payments/charge'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'amount': (amount * 100).toInt(),
          'currency': currency ?? 'usd',
          'cardNumber': cardNumber.replaceAll(RegExp(r'\s+'), ''),
          'expiryMonth': expiryMonth,
          'expiryYear': expiryYear,
          'cvv': cvv,
          'cardholderName': cardholderName,
          'description': description ?? 'WatchHub Purchase',
        }),
      ).timeout(const Duration(seconds: 30));
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        Logger.info('Payment successful: ${data['transactionId']}');
        return PaymentResult(
          success: true,
          transactionId: data['transactionId'],
          receiptUrl: data['receiptUrl'],
        );
      }
      return PaymentResult(
        success: false,
        error: data['error'] ?? 'Payment failed',
      );
    } catch (e) {
      Logger.error('Payment error', e);
      if (e.toString().contains('TimeoutException')) {
        return PaymentResult(success: false, error: 'Payment timed out');
      }
      return PaymentResult(success: false, error: 'Payment processing failed');
    }
  }

  Future<PaymentResult> simulatePayment({
    required double amount,
    required String cardholderName,
  }) async {
    await Future.delayed(const Duration(seconds: 2));
    final success = amount > 0;
    if (success) {
      return PaymentResult(
        success: true,
        transactionId: 'txn_${DateTime.now().millisecondsSinceEpoch}',
        receiptUrl: null,
      );
    }
    return PaymentResult(success: false, error: 'Invalid amount');
  }

  static String maskCardNumber(String cardNumber) {
    final cleaned = cardNumber.replaceAll(RegExp(r'\s+'), '');
    if (cleaned.length < 4) return cleaned;
    return '**** **** **** ${cleaned.substring(cleaned.length - 4)}';
  }

  static String formatCardNumber(String value) {
    final cleaned = value.replaceAll(RegExp(r'\D'), '');
    final buffer = StringBuffer();
    for (int i = 0; i < cleaned.length; i++) {
      if (i > 0 && i % 4 == 0) buffer.write(' ');
      buffer.write(cleaned[i]);
    }
    return buffer.toString();
  }

  static bool validateCardNumber(String cardNumber) {
    final cleaned = cardNumber.replaceAll(RegExp(r'\s+'), '');
    if (cleaned.length < 13 || cleaned.length > 19) return false;
    if (!RegExp(r'^\d+$').hasMatch(cleaned)) return false;
    int sum = 0;
    bool alternate = false;
    for (int i = cleaned.length - 1; i >= 0; i--) {
      int digit = int.parse(cleaned[i]);
      if (alternate) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      sum += digit;
      alternate = !alternate;
    }
    return sum % 10 == 0;
  }

  static bool validateExpiry(String month, String year) {
    try {
      final m = int.parse(month);
      final y = int.parse(year);
      if (m < 1 || m > 12) return false;
      final now = DateTime.now();
      final expiry = DateTime(y + 2000, m + 1, 0);
      return expiry.isAfter(now);
    } catch (_) {
      return false;
    }
  }

  static bool validateCVV(String cvv) {
    return RegExp(r'^\d{3,4}$').hasMatch(cvv);
  }
}
