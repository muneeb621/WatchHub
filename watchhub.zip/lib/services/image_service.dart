import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

class ImageService {
  static final ImagePicker _picker = ImagePicker();

  static Future<File?> pickFromGallery() async {
    if (kIsWeb) return null;
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      if (picked != null) return File(picked.path);
    } catch (_) {}
    return null;
  }

  static Future<File?> pickFromCamera() async {
    if (kIsWeb) return null;
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      if (picked != null) return File(picked.path);
    } catch (_) {}
    return null;
  }
}
