import 'package:cloud_firestore/cloud_firestore.dart' hide Order;
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/models/review.dart';
import 'package:watchhub/models/category.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/models/user.dart';
import 'package:watchhub/models/feedback_item.dart';
import 'package:watchhub/services/firebase_service.dart';

class ApiService {
  static final ApiService _instance = ApiService._();
  factory ApiService() => _instance;
  ApiService._() {
    _initMockData();
  }

  bool get _useFirebase => FirebaseService.isFirestoreAvailable;

  CollectionReference get _watchesRef => FirebaseService.firestore.collection('watches');
  CollectionReference get _reviewsRef => FirebaseService.firestore.collection('reviews');
  CollectionReference get _categoriesRef => FirebaseService.firestore.collection('categories');

  // Mutable mock data for admin CRUD
  late List<Watch> _mockWatches;
  late List<Category> _mockCategories;
  late List<Review> _mockReviews;
  late List<Order> _mockOrders;
  late List<User> _mockUsers;
  final List<FeedbackItem> _mockFeedback = [];

  void _initMockData() {
    _mockWatches = _seedMockWatches();
    _mockCategories = _seedMockCategories();
    _mockReviews = _seedMockReviews();
    _mockOrders = [];
    _mockOrders.addAll(_seedMockOrders());
    _mockUsers = _seedMockUsers();
  }

  // --- Watches ---

  Future<List<Watch>> getWatches({
    String? brand, String? type, String? sortBy,
    double? minPrice, double? maxPrice, String? searchQuery,
  }) async {
    if (_useFirebase) {
      try {
        var query = _watchesRef as Query;
        if (brand != null) query = query.where('brand', isEqualTo: brand);
        if (type != null) query = query.where('type', isEqualTo: type);
        if (minPrice != null) query = query.where('price', isGreaterThanOrEqualTo: minPrice);
        if (maxPrice != null) query = query.where('price', isLessThanOrEqualTo: maxPrice);
        if (sortBy != null) {
          switch (sortBy) {
            case 'Price: Low to High': query = query.orderBy('price', descending: false);
            case 'Price: High to Low': query = query.orderBy('price', descending: true);
            case 'Rating': query = query.orderBy('rating', descending: true);
            case 'Popularity': query = query.orderBy('reviewCount', descending: true);
          }
        }
        final snapshot = await query.get();
        var watches = snapshot.docs.map((d) => Watch.fromMap({...d.data() as Map, 'id': d.id})).toList();
        if (searchQuery != null && searchQuery.isNotEmpty) {
          final q = searchQuery.toLowerCase();
          watches = watches.where((w) =>
            w.name.toLowerCase().contains(q) ||
            w.brand.toLowerCase().contains(q)
          ).toList();
        }
        return watches;
      } catch (_) {}
    }
    return _mockGetWatches(brand: brand, type: type, sortBy: sortBy, minPrice: minPrice, maxPrice: maxPrice, searchQuery: searchQuery);
  }

  Future<List<Watch>> getPopularWatches() async {
    if (_useFirebase) {
      try {
        final snapshot = await _watchesRef.where('isPopular', isEqualTo: true).limit(10).get();
        return snapshot.docs.map((d) => Watch.fromMap({...d.data() as Map, 'id': d.id})).toList();
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return _mockWatches.where((w) => w.isPopular).toList();
  }

  Future<List<Watch>> getNewArrivals() async {
    if (_useFirebase) {
      try {
        final snapshot = await _watchesRef.where('isNewArrival', isEqualTo: true).limit(10).get();
        return snapshot.docs.map((d) => Watch.fromMap({...d.data() as Map, 'id': d.id})).toList();
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return _mockWatches.where((w) => w.isNewArrival).toList();
  }

  Future<List<Category>> getCategories() async {
    if (_useFirebase) {
      try {
        final snapshot = await _categoriesRef.get();
        return snapshot.docs.map((d) => Category.fromMap({...d.data() as Map, 'id': d.id})).toList();
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return List.from(_mockCategories);
  }

  Future<List<Review>> getReviews(String watchId) async {
    if (_useFirebase) {
      try {
        final snapshot = await _reviewsRef.where('watchId', isEqualTo: watchId).orderBy('createdAt', descending: true).get();
        return snapshot.docs.map((d) => Review.fromMap({...d.data() as Map, 'id': d.id})).toList();
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return _mockReviews.where((r) => r.watchId == watchId).toList();
  }

  Future<List<Review>> getAllReviews() async {
    if (_useFirebase) {
      try {
        final snapshot = await _reviewsRef.orderBy('createdAt', descending: true).get();
        return snapshot.docs.map((d) => Review.fromMap({...d.data() as Map, 'id': d.id})).toList();
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return List.from(_mockReviews);
  }

  Future<Watch> getWatchById(String id) async {
    if (_useFirebase) {
      try {
        final doc = await _watchesRef.doc(id).get();
        return Watch.fromMap({...doc.data() as Map, 'id': doc.id});
      } catch (_) {}
    }
    await Future.delayed(const Duration(milliseconds: 100));
    return _mockWatches.firstWhere((w) => w.id == id);
  }

  Future<void> addReview(Review review) async {
    if (_useFirebase) {
      try { await _reviewsRef.add(review.toMap()); } catch (_) {}
    }
    _mockReviews.insert(0, review);
  }

  Future<void> deleteReview(String reviewId) async {
    if (_useFirebase) {
      try {
        final query = await _reviewsRef.where('id', isEqualTo: reviewId).get();
        for (final doc in query.docs) { await doc.reference.delete(); }
      } catch (_) {}
    }
    _mockReviews.removeWhere((r) => r.id == reviewId);
  }

  // --- Feedback ---

  Future<void> addFeedback(FeedbackItem item) async {
    if (_useFirebase) {
      try {
        await FirebaseService.firestore.collection('feedback').add(item.toMap());
      } catch (_) {}
    }
    _mockFeedback.add(item);
  }

  // --- Admin: Product CRUD ---

  Future<void> addWatch(Watch watch) async {
    if (_useFirebase) {
      try { await _watchesRef.add(watch.toMap()); } catch (_) {}
    }
    _mockWatches.add(watch);
  }

  Future<void> updateWatch(String id, Map<String, dynamic> data) async {
    if (_useFirebase) {
      try { await _watchesRef.doc(id).update(data); } catch (_) {}
    }
    final idx = _mockWatches.indexWhere((w) => w.id == id);
    if (idx >= 0) {
      final old = _mockWatches[idx];
      _mockWatches[idx] = Watch(
        id: old.id, name: data['name'] ?? old.name,
        brand: data['brand'] ?? old.brand, type: data['type'] ?? old.type,
        description: data['description'] ?? old.description,
        price: (data['price'] ?? old.price).toDouble(),
        originalPrice: (data['originalPrice'] ?? old.originalPrice).toDouble(),
        rating: (data['rating'] ?? old.rating).toDouble(),
        reviewCount: data['reviewCount'] ?? old.reviewCount,
        stock: data['stock'] ?? old.stock,
        images: data['images'] ?? old.images,
        specifications: data['specifications'] ?? old.specifications,
        isPopular: data['isPopular'] ?? old.isPopular,
        isNewArrival: data['isNewArrival'] ?? old.isNewArrival,
        discountTag: data['discountTag'] ?? old.discountTag,
      );
    }
  }

  Future<void> deleteWatch(String id) async {
    if (_useFirebase) {
      try { await _watchesRef.doc(id).delete(); } catch (_) {}
    }
    _mockWatches.removeWhere((w) => w.id == id);
  }

  // --- Admin: Orders ---

  List<Order> getOrders({String? userId}) {
    if (userId != null) {
      return _mockOrders.where((o) => o.userId == userId).toList();
    }
    return List.unmodifiable(_mockOrders);
  }

  Future<void> updateOrderStatus(String orderId, OrderStatus status) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('orders').doc(orderId).update({'status': status.index}); } catch (_) {}
    }
    final idx = _mockOrders.indexWhere((o) => o.id == orderId);
    if (idx >= 0) {
      final o = _mockOrders[idx];
      _mockOrders[idx] = Order(
        id: o.id, userId: o.userId, items: o.items,
        totalAmount: o.totalAmount, shippingAddress: o.shippingAddress,
        status: status, createdAt: o.createdAt,
        deliveredAt: status == OrderStatus.delivered ? DateTime.now() : o.deliveredAt,
        trackingNumber: o.trackingNumber,
      );
    }
  }

  Future<void> updateOrderTracking(String orderId, String trackingNumber) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('orders').doc(orderId).update({'trackingNumber': trackingNumber}); } catch (_) {}
    }
    final idx = _mockOrders.indexWhere((o) => o.id == orderId);
    if (idx >= 0) {
      final o = _mockOrders[idx];
      _mockOrders[idx] = Order(
        id: o.id, userId: o.userId, items: o.items,
        totalAmount: o.totalAmount, shippingAddress: o.shippingAddress,
        status: o.status, createdAt: o.createdAt,
        deliveredAt: o.deliveredAt, trackingNumber: trackingNumber,
      );
    }
  }

  Future<void> placeOrder(Map<String, dynamic> orderData) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('orders').add(orderData); } catch (_) {}
    }
    _mockOrders.add(Order.fromMap(orderData));
  }

  // --- Admin: Users ---

  List<User> getAllUsers() {
    return List.unmodifiable(_mockUsers);
  }

  Future<void> addUser(User user) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('users').doc(user.id).set(user.toMap()); } catch (_) {}
    }
    _mockUsers.add(user);
  }

  Future<void> updateUser(String userId, Map<String, dynamic> data) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('users').doc(userId).update(data); } catch (_) {}
    }
    final idx = _mockUsers.indexWhere((u) => u.id == userId);
    if (idx >= 0) {
      final old = _mockUsers[idx];
      _mockUsers[idx] = User(
        id: old.id, email: data['email'] ?? old.email,
        name: data['name'] ?? old.name,
        phone: data['phone'] ?? old.phone,
        avatarUrl: data['avatarUrl'] ?? old.avatarUrl,
        shippingAddresses: data['shippingAddresses'] ?? old.shippingAddresses,
        isAdmin: data['isAdmin'] ?? old.isAdmin,
      );
    }
  }

  Future<void> deleteUser(String userId) async {
    if (_useFirebase) {
      try { await FirebaseService.firestore.collection('users').doc(userId).delete(); } catch (_) {}
    }
    _mockUsers.removeWhere((u) => u.id == userId);
  }

  // --- Mock Data Seed ---

  List<Watch> _seedMockWatches() {
    return [
      Watch(id: '1', name: 'Rolex Submariner', brand: 'Rolex', type: 'Diver',
        description: 'The iconic Rolex Submariner is the definitive divers watch.',
        price: 9500, originalPrice: 10500, rating: 4.8, reviewCount: 234, stock: 5,
        images: ['https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800'],
        specifications: ['Water resistant to 300m', 'Automatic movement', '40mm case', 'Ceramic bezel'],
        isPopular: true, discountTag: '10% OFF'),
      Watch(id: '2', name: 'Omega Speedmaster', brand: 'Omega', type: 'Chronograph',
        description: 'The Omega Speedmaster Moonwatch is legendary as the first watch worn on the moon.',
        price: 7200, rating: 4.7, reviewCount: 189, stock: 8,
        images: ['https://images.unsplash.com/photo-1756043818833-c2d8d4f67465?w=800'],
        specifications: ['Manual winding chronograph', '42mm case', 'Sapphire crystal', '50 hours power reserve'],
        isPopular: true, isNewArrival: true),
      Watch(id: '3', name: 'Tag Heuer Carrera', brand: 'Tag Heuer', type: 'Chronograph',
        description: 'The Tag Heuer Carrera collection embodies the spirit of motor racing.',
        price: 5400, rating: 4.6, reviewCount: 156, stock: 12,
        images: ['https://images.unsplash.com/photo-1773270875843-4e4a21798c5e?w=800'],
        specifications: ['Automatic chronograph', '43mm case', '100m water resistance', 'Sapphire crystal'],
        isPopular: true),
      Watch(id: '4', name: 'Seiko Presage', brand: 'Seiko', type: 'Dress',
        description: 'The Seiko Presage combines Japanese craftsmanship with elegant design.',
        price: 1200, originalPrice: 1500, rating: 4.5, reviewCount: 312, stock: 25,
        images: ['https://images.unsplash.com/photo-1568154106189-717dc85a0b3b?w=800'],
        specifications: ['Automatic movement', '40.5mm case', 'See-through caseback', 'Date display'],
        discountTag: '20% OFF', isNewArrival: true),
      Watch(id: '5', name: 'Citizen Eco-Drive', brand: 'Citizen', type: 'Analog',
        description: 'Powered by light, the Citizen Eco-Drive never needs a battery.',
        price: 450, rating: 4.4, reviewCount: 567, stock: 50,
        images: ['https://images.unsplash.com/photo-1770653336729-19426ff1f131?w=800'],
        specifications: ['Eco-Drive movement', '42mm case', '200m water resistance', 'Date display'],
        isPopular: true),
      Watch(id: '6', name: 'Casio G-Shock', brand: 'Casio', type: 'Digital',
        description: 'Virtually indestructible, the G-Shock is the ultimate tough watch.',
        price: 180, originalPrice: 250, rating: 4.6, reviewCount: 890, stock: 100,
        images: ['https://images.unsplash.com/photo-1779001643179-b162d33d4ee4?w=800'],
        specifications: ['Quartz movement', 'Shock resistant', '200m water resistance', 'LED light'],
        discountTag: '28% OFF', isPopular: true),
      Watch(id: '7', name: 'Fossil Gen 6', brand: 'Fossil', type: 'Smartwatch',
        description: 'The Fossil Gen 6 combines classic watch design with cutting-edge smart technology.',
        price: 299, rating: 4.3, reviewCount: 423, stock: 35,
        images: ['https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=800'],
        specifications: ['Wear OS', 'Heart rate monitor', 'GPS', '24-hour battery'],
        isNewArrival: true),
      Watch(id: '8', name: 'Tissot Le Locle', brand: 'Tissot', type: 'Dress',
        description: 'Named after the birthplace of Tissot, the Le Locle represents traditional Swiss watchmaking.',
        price: 850, rating: 4.5, reviewCount: 234, stock: 18,
        images: ['https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=800'],
        specifications: ['Automatic movement', '39.3mm case', '50m water resistance', 'Date display'],
        isNewArrival: true),
      Watch(id: '9', name: 'Longines Master Collection', brand: 'Longines', type: 'Automatic',
        description: 'The Longines Master Collection embodies elegance and tradition.',
        price: 3200, rating: 4.7, reviewCount: 145, stock: 7,
        images: ['https://images.unsplash.com/photo-1663564307096-e635ce2addeb?w=800'],
        specifications: ['Automatic movement', '40mm case', '30m water resistance', 'Moon phase'],
        isPopular: true),
      Watch(id: '10', name: 'Timex Expedition', brand: 'Timex', type: 'Sports',
        description: 'Built for adventure, the Timex Expedition is rugged, reliable, and ready for the outdoors.',
        price: 85, rating: 4.2, reviewCount: 1023, stock: 200,
        images: ['https://images.unsplash.com/photo-1763762001154-b642050f634d?w=800'],
        specifications: ['Quartz movement', '43mm case', '100m water resistance', 'Indiglo night-light'],
        isPopular: true),
      Watch(id: '11', name: 'Breitling Navitimer', brand: 'Breitling', type: 'Chronograph',
        description: 'The Breitling Navitimer features a built-in flight computer for aviation professionals.',
        price: 6800, originalPrice: 7500, rating: 4.7, reviewCount: 98, stock: 6,
        images: ['https://images.unsplash.com/photo-1548169874-53e85f753f1e?w=800'],
        specifications: ['Automatic chronograph', '43mm case', '30m water resistance', 'Slide rule bezel'],
        isPopular: true, isNewArrival: true, discountTag: '9% OFF'),
      Watch(id: '12', name: 'Patek Philippe Nautilus', brand: 'Patek Philippe', type: 'Luxury',
        description: 'The Patek Philippe Nautilus is an icon of luxury sports watch design.',
        price: 35000, rating: 4.9, reviewCount: 67, stock: 2,
        images: ['https://images.unsplash.com/photo-1710671544323-8e448efa283e?w=800'],
        specifications: ['Automatic movement', '40mm case', '120m water resistance', 'Sapphire crystal'],
        isPopular: true, isNewArrival: true),
      Watch(id: '13', name: 'Hublot Big Bang', brand: 'Hublot', type: 'Sports',
        description: 'The Hublot Big Bang is a bold fusion of materials and avant-garde design.',
        price: 15000, rating: 4.5, reviewCount: 134, stock: 4,
        images: ['https://images.unsplash.com/photo-1772638904164-eed7c6b1e57e?w=800'],
        specifications: ['Automatic chronograph', '45mm case', '100m water resistance', 'Rubber strap'],
        isNewArrival: true),
      Watch(id: '14', name: 'IWC Portugieser', brand: 'IWC', type: 'Dress',
        description: 'The IWC Portugieser embodies refined elegance with its clean dial and precision movement.',
        price: 7500, rating: 4.6, reviewCount: 89, stock: 9,
        images: ['https://images.unsplash.com/photo-1777457797327-571e21f193b0?w=800'],
        specifications: ['Automatic movement', '42.3mm case', '60h power reserve', 'See-through caseback'],
        isNewArrival: true, isPopular: true),
    ];
  }

  List<Category> _seedMockCategories() {
    return [
      Category(id: '1', name: 'Luxury', imageUrl: 'https://images.unsplash.com/photo-1710671544323-8e448efa283e?w=400'),
      Category(id: '2', name: 'Sports', imageUrl: 'https://images.unsplash.com/photo-1763762001154-b642050f634d?w=400'),
      Category(id: '3', name: 'Dress', imageUrl: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=400'),
      Category(id: '4', name: 'Smart', imageUrl: 'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=400'),
      Category(id: '5', name: 'Diver', imageUrl: 'https://images.unsplash.com/photo-1779001643179-b162d33d4ee4?w=400'),
      Category(id: '6', name: 'Digital', imageUrl: 'https://images.unsplash.com/photo-1548169874-53e85f753f1e?w=400'),
    ];
  }

  List<Review> _seedMockReviews() {
    return [
      Review(id: '1', watchId: '1', userId: 'u1', userName: 'John D.', rating: 5, comment: 'Absolutely stunning watch!', helpfulCount: 45),
      Review(id: '2', watchId: '1', userId: 'u2', userName: 'Sarah M.', rating: 4, comment: 'Beautiful watch, but a bit heavy on the wrist.', helpfulCount: 23),
      Review(id: '3', watchId: '1', userId: 'u3', userName: 'Mike R.', rating: 5, comment: 'A true icon. Worth every penny.', helpfulCount: 67),
      Review(id: '4', watchId: '2', userId: 'u4', userName: 'Alex K.', rating: 5, comment: 'The Moonwatch exceeded my expectations.', helpfulCount: 34),
      Review(id: '5', watchId: '2', userId: 'u5', userName: 'Emily W.', rating: 4, comment: 'Great watch, but the manual winding takes getting used to.', helpfulCount: 12),
      Review(id: '6', watchId: '3', userId: 'u1', userName: 'John D.', rating: 4, comment: 'Solid build quality and accurate timing.', helpfulCount: 8),
    ];
  }

  List<User> _seedMockUsers() {
    return [
      User(id: 'u1', name: 'John Doe', email: 'john@example.com', phone: '+1 555-0101', isAdmin: false, createdAt: DateTime.now().subtract(const Duration(days: 30))),
      User(id: 'u2', name: 'Sarah Smith', email: 'sarah@example.com', phone: '+1 555-0102', isAdmin: false, createdAt: DateTime.now().subtract(const Duration(days: 25))),
      User(id: 'u3', name: 'Mike Johnson', email: 'mike@example.com', phone: '+1 555-0103', isAdmin: false, createdAt: DateTime.now().subtract(const Duration(days: 20))),
      User(id: 'u4', name: 'Emily Davis', email: 'emily@example.com', phone: '+1 555-0104', isAdmin: false, createdAt: DateTime.now().subtract(const Duration(days: 15))),
      User(id: 'u5', name: 'Admin User', email: 'admin@watchhub.com', phone: '+1 555-0000', isAdmin: true, createdAt: DateTime.now().subtract(const Duration(days: 90))),
    ];
  }

  List<Order> _seedMockOrders() {
    return [
      Order(
        id: 'ord1', userId: 'u1',
        items: [
          OrderItem(watchId: '1', watchName: _mockWatches[0].name, watchImage: _mockWatches[0].images.first, price: _mockWatches[0].price, quantity: 1),
          OrderItem(watchId: '6', watchName: _mockWatches[5].name, watchImage: _mockWatches[5].images.first, price: _mockWatches[5].price, quantity: 2),
        ],
        totalAmount: _mockWatches[0].price + _mockWatches[5].price * 2,
        shippingAddress: '123 Main St, New York, NY 10001',
        status: OrderStatus.delivered,
        createdAt: DateTime.now().subtract(const Duration(days: 14)),
        deliveredAt: DateTime.now().subtract(const Duration(days: 10)),
        trackingNumber: 'TRK9847321',
      ),
      Order(
        id: 'ord2', userId: 'u1',
        items: [
          OrderItem(watchId: '4', watchName: _mockWatches[3].name, watchImage: _mockWatches[3].images.first, price: _mockWatches[3].price, quantity: 1),
        ],
        totalAmount: _mockWatches[3].price,
        shippingAddress: '456 Oak Ave, Los Angeles, CA 90001',
        status: OrderStatus.shipped,
        createdAt: DateTime.now().subtract(const Duration(days: 3)),
        trackingNumber: 'TRK1098765',
      ),
      Order(
        id: 'ord3', userId: 'u1',
        items: [
          OrderItem(watchId: '7', watchName: _mockWatches[6].name, watchImage: _mockWatches[6].images.first, price: _mockWatches[6].price, quantity: 1),
        ],
        totalAmount: _mockWatches[6].price,
        shippingAddress: '789 Pine Rd, Chicago, IL 60601',
        status: OrderStatus.pending,
        createdAt: DateTime.now().subtract(const Duration(hours: 2)),
      ),
    ];
  }

  List<Watch> _mockGetWatches({String? brand, String? type, String? sortBy, double? minPrice, double? maxPrice, String? searchQuery}) {
    var watches = List<Watch>.from(_mockWatches);
    if (brand != null) watches = watches.where((w) => w.brand == brand).toList();
    if (type != null) watches = watches.where((w) => w.type == type).toList();
    if (minPrice != null) watches = watches.where((w) => w.price >= minPrice).toList();
    if (maxPrice != null) watches = watches.where((w) => w.price <= maxPrice).toList();
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final q = searchQuery.toLowerCase();
      watches = watches.where((w) => w.name.toLowerCase().contains(q) || w.brand.toLowerCase().contains(q) || w.description.toLowerCase().contains(q)).toList();
    }
    if (sortBy != null) {
      switch (sortBy) {
        case 'Price: Low to High': watches.sort((a, b) => a.price.compareTo(b.price));
        case 'Price: High to Low': watches.sort((a, b) => b.price.compareTo(a.price));
        case 'Rating': watches.sort((a, b) => b.rating.compareTo(a.rating));
        case 'Popularity': watches.sort((a, b) => b.reviewCount.compareTo(a.reviewCount));
      }
    }
    return watches;
  }
}
