import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/services/api_service.dart';
import 'package:watchhub/services/firebase_service.dart';
import 'package:watchhub/utils/logger.dart';

class TrackingUpdate {
  final String orderId;
  final OrderStatus status;
  final String? trackingNumber;
  final DateTime timestamp;

  TrackingUpdate({
    required this.orderId,
    required this.status,
    this.trackingNumber,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class TrackingService with ChangeNotifier {
  static final TrackingService _instance = TrackingService._();
  factory TrackingService() => _instance;
  TrackingService._();

  final ApiService _apiService = ApiService();
  final Map<String, List<TrackingUpdate>> _trackingHistory = {};
  StreamSubscription? _firestoreSubscription;

  bool _isListening = false;
  bool get isListening => _isListening;

  void startListening(String orderId) {
    if (!FirebaseService.isFirestoreAvailable) return;
    try {
      _firestoreSubscription = FirebaseService.firestore
          .collection('orders')
          .doc(orderId)
          .snapshots()
          .listen((snapshot) {
        if (!snapshot.exists) return;
        final data = snapshot.data() as Map<String, dynamic>;
        final status = OrderStatus.values[data['status'] ?? 0];
        final trackingNumber = data['trackingNumber'] as String?;
        final update = TrackingUpdate(
          orderId: orderId,
          status: status,
          trackingNumber: trackingNumber,
        );
        _addUpdate(orderId, update);
      }, onError: (e) {
        Logger.error('Tracking stream error', e);
      });
      _isListening = true;
    } catch (e) {
      Logger.error('Failed to start tracking', e);
    }
  }

  void stopListening() {
    _firestoreSubscription?.cancel();
    _firestoreSubscription = null;
    _isListening = false;
  }

  void _addUpdate(String orderId, TrackingUpdate update) {
    _trackingHistory[orderId] ??= [];
    _trackingHistory[orderId]!.add(update);
    notifyListeners();
  }

  List<TrackingUpdate> getTrackingHistory(String orderId) {
    return List.unmodifiable(_trackingHistory[orderId] ?? []);
  }

  TrackingUpdate? getLatestUpdate(String orderId) {
    final history = _trackingHistory[orderId];
    if (history == null || history.isEmpty) return null;
    return history.last;
  }

  Future<OrderStatus> checkOrderStatus(String orderId) async {
    try {
      final orders = _apiService.getOrders();
      final order = orders.where((o) => o.id == orderId).firstOrNull;
      if (order != null) {
        final update = TrackingUpdate(orderId: orderId, status: order.status);
        _addUpdate(orderId, update);
        return order.status;
      }
    } catch (e) {
      Logger.error('Status check error', e);
    }
    return OrderStatus.pending;
  }

  @override
  void dispose() {
    stopListening();
    super.dispose();
  }
}
