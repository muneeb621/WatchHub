import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:watchhub/services/firebase_service.dart';
import 'package:watchhub/utils/logger.dart';

class NotificationData {
  final String? title;
  final String? body;
  final String? type;
  final String? payload;

  NotificationData({this.title, this.body, this.type, this.payload});

  factory NotificationData.fromMap(Map<String, dynamic> map) {
    return NotificationData(
      title: map['title'],
      body: map['body'],
      type: map['type'],
      payload: map['payload'],
    );
  }
}

class NotificationService with ChangeNotifier {
  static final NotificationService _instance = NotificationService._();
  factory NotificationService() => _instance;
  NotificationService._();

  bool _initialized = false;
  bool _notificationsEnabled = true;
  String? _fcmToken;
  final List<NotificationData> _pendingNotifications = [];
  final StreamController<NotificationData> _notificationController = StreamController.broadcast();

  bool get initialized => _initialized;
  bool get notificationsEnabled => _notificationsEnabled;
  String? get fcmToken => _fcmToken;
  List<NotificationData> get pendingNotifications => List.unmodifiable(_pendingNotifications);
  Stream<NotificationData> get notificationStream => _notificationController.stream;

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    final prefs = await SharedPreferences.getInstance();
    _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
    _fcmToken = prefs.getString('fcm_token');
    if (FirebaseService.isAvailable) {
      try {
        Logger.info('FCM initialized');
      } catch (e) {
        Logger.error('FCM init error', e);
      }
    }
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    _notificationsEnabled = enabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', enabled);
    notifyListeners();
  }

  void onNotificationReceived(NotificationData notification) {
    _pendingNotifications.add(notification);
    _notificationController.add(notification);
    notifyListeners();
  }

  void clearPendingNotifications() {
    _pendingNotifications.clear();
    notifyListeners();
  }

  void removePendingNotification(int index) {
    if (index >= 0 && index < _pendingNotifications.length) {
      _pendingNotifications.removeAt(index);
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _notificationController.close();
    super.dispose();
  }
}
