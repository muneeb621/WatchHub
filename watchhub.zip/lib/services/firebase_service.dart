import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static bool _initialized = false;
  static bool _available = false;
  static bool _firestoreAvailable = false;

  static bool get isAvailable => _initialized && _available;
  static bool get isFirestoreAvailable => _firestoreAvailable;

  static Future<bool> initialize({FirebaseOptions? options}) async {
    if (_initialized) return _available;
    _initialized = true;
    try {
      if (options != null) {
        await Firebase.initializeApp(options: options).timeout(const Duration(seconds: 5));
      } else {
        await Firebase.initializeApp().timeout(const Duration(seconds: 5));
      }
      _available = true;
      unawaited(_checkFirestore());
    } catch (_) {
      _available = false;
    }
    return _available;
  }

  static Future<void> _checkFirestore() async {
    try {
      await FirebaseFirestore.instance.collection('_health_check').limit(1).get().timeout(const Duration(seconds: 2));
      _firestoreAvailable = true;
    } catch (_) {
      _firestoreAvailable = false;
    }
  }

  static Future<void> resetPassword(String email) async {
    if (!_available) throw Exception('Firebase not available');
    await FirebaseAuth.instance.sendPasswordResetEmail(email: email).timeout(const Duration(seconds: 10));
  }

  static User? get currentUser => _available ? FirebaseAuth.instance.currentUser : null;
  static FirebaseFirestore get firestore => FirebaseFirestore.instance;
  static FirebaseAuth get auth => FirebaseAuth.instance;
}
