import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/app.dart';
import 'package:watchhub/firebase_options.dart';
import 'package:watchhub/l10n/l10n.dart';
import 'package:watchhub/services/firebase_service.dart';
import 'package:watchhub/services/notification_service.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/providers/theme_provider.dart';
import 'package:watchhub/providers/watch_provider.dart';
import 'package:watchhub/providers/cart_provider.dart';
import 'package:watchhub/providers/wishlist_provider.dart';
import 'package:watchhub/providers/review_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService.initialize(options: DefaultFirebaseOptions.currentPlatform);
  final notifService = NotificationService();
  await notifService.initialize();
  final authProvider = AuthProvider();
  await authProvider.tryAutoLogin();
  final cartProvider = CartProvider();
  await cartProvider.loadCart();
  final wishlistProvider = WishlistProvider();
  await wishlistProvider.loadWishlist();
  final reviewProvider = ReviewProvider();
  await reviewProvider.fetchAllReviews();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider.value(value: notifService),
        ChangeNotifierProvider.value(value: authProvider),
        ChangeNotifierProvider(create: (_) => WatchProvider()),
        ChangeNotifierProvider.value(value: cartProvider),
        ChangeNotifierProvider.value(value: wishlistProvider),
        ChangeNotifierProvider.value(value: reviewProvider),
      ],
      child: const WatchHubApp(),
    ),
  );
}
