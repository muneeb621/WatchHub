import 'package:flutter/material.dart';

class ShimmerLoading extends StatefulWidget {
  final Widget child;

  const ShimmerLoading({super.key, required this.child});

  @override
  State<ShimmerLoading> createState() => _ShimmerLoadingState();
}

class _ShimmerLoadingState extends State<ShimmerLoading>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
    _animation = Tween<double>(begin: -1.0, end: 2.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutSine),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (_, child) => ShaderMask(
        blendMode: BlendMode.srcATop,
        shaderCallback: (bounds) => LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.topRight,
          colors: const [
            Color(0xFF2A2A2A),
            Color(0xFF3A3A3A),
            Color(0xFF5A5A5A),
            Color(0xFF3A3A3A),
            Color(0xFF2A2A2A),
          ],
          stops: [
            0.0,
            _animation.value - 0.3,
            _animation.value,
            _animation.value + 0.3,
            1.0,
          ],
        ).createShader(bounds),
        child: child!,
      ),
      child: widget.child,
    );
  }
}

class ShimmerCard extends StatelessWidget {
  final double width;
  final double height;

  const ShimmerCard({super.key, this.width = double.infinity, this.height = 120});

  @override
  Widget build(BuildContext context) {
    return ShimmerLoading(
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}

class ShimmerGrid extends StatelessWidget {
  final int count;
  final double aspectRatio;

  const ShimmerGrid({super.key, this.count = 6, this.aspectRatio = 0.77});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, constraints) {
        final crossAxisCount = constraints.maxWidth > 600 ? 3 : 2;
        final itemWidth = (constraints.maxWidth - 12 - (crossAxisCount - 1) * 8) / crossAxisCount;
        final itemHeight = itemWidth / aspectRatio;
        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: List.generate(count, (_) => ShimmerCard(
            width: itemWidth,
            height: itemHeight,
          )),
        );
      },
    );
  }
}
