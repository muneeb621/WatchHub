import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/review.dart';

class ReviewCard extends StatelessWidget {
  final Review review;
  final VoidCallback? onHelpfulTap;

  const ReviewCard({super.key, required this.review, this.onHelpfulTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundImage: review.userAvatar != null ? NetworkImage(review.userAvatar!) : null,
                  child: review.userAvatar == null
                      ? Text(
                          review.userName.isNotEmpty ? review.userName[0].toUpperCase() : '?',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(review.userName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const SizedBox(height: 2),
                      Text(
                        DateFormat('MMM dd, yyyy').format(review.createdAt),
                        style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: List.generate(5, (i) => Icon(i < review.rating.round() ? Icons.star : Icons.star_border, size: 16, color: Colors.amber)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(review.comment, style: const TextStyle(fontSize: 14, height: 1.4)),
            const SizedBox(height: 12),
            Row(
              children: [
                InkWell(
                  onTap: onHelpfulTap,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppTheme.textSecondary.withValues(alpha: 0.3)),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.thumb_up_outlined, size: 14, color: AppTheme.textSecondary),
                        const SizedBox(width: 4),
                        Text('Helpful (${review.helpfulCount})', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
