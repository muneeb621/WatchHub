import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/providers/wishlist_provider.dart';

class WatchCard extends StatelessWidget {
  final Watch watch;

  const WatchCard({super.key, required this.watch});

  @override
  Widget build(BuildContext context) {
    final wishlist = context.watch<WishlistProvider>();
    final isWishlisted = wishlist.isInWishlist(watch.id);
    final hasDiscount = watch.originalPrice > watch.price;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, AppRoutes.productDetail, arguments: watch),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isGrid = constraints.maxWidth < 250;
            return isGrid ? _buildGridLayout(context, wishlist, isWishlisted, hasDiscount) : _buildListLayout(context, wishlist, isWishlisted, hasDiscount);
          },
        ),
      ),
    );
  }

  Widget _buildGridLayout(BuildContext context, WishlistProvider wishlist, bool isWishlisted, bool hasDiscount) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            AspectRatio(
              aspectRatio: 1.2,
              child: Container(
                color: const Color(0xFF2A2A2A),
                child: CachedNetworkImage(
                  imageUrl: watch.images.first,
                  fit: BoxFit.contain,
                  placeholder: (_, _) => const Center(child: CircularProgressIndicator()),
                  errorWidget: (_, _, _) => const Center(child: Icon(Icons.watch, size: 48)),
                ),
              ),
            ),
            Positioned(
              top: 4,
              right: 4,
              child: IconButton(
                icon: Icon(
                  isWishlisted ? Icons.favorite : Icons.favorite_border,
                  color: isWishlisted ? Colors.red : Colors.white,
                ),
                onPressed: () => wishlist.toggle(watch),
              ),
            ),
            if (hasDiscount)
              Positioned(
                top: 4,
                left: 4,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.accentColor,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    watch.discountTag ?? '${watch.discountPercentage.toStringAsFixed(0)}% OFF',
                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(watch.brand, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
              const SizedBox(height: 2),
              Text(watch.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 3),
              Row(
                children: [
                  ...List.generate(5, (i) => Icon(i < watch.rating.round() ? Icons.star : Icons.star_border, size: 12, color: Colors.amber)),
                  const SizedBox(width: 3),
                  Text('(${watch.reviewCount})', style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
                ],
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  Flexible(
                    child:                     Text('\$${watch.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white), overflow: TextOverflow.ellipsis),
                  ),
                  if (hasDiscount) ...[
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text('\$${watch.originalPrice.toStringAsFixed(0)}', style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary, decoration: TextDecoration.lineThrough), overflow: TextOverflow.ellipsis),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildListLayout(BuildContext context, WishlistProvider wishlist, bool isWishlisted, bool hasDiscount) {
    return Row(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
          child: SizedBox(
            width: 120,
            height: 120,
            child: CachedNetworkImage(
              imageUrl: watch.images.first,
              fit: BoxFit.cover,
              placeholder: (_, _) => const Center(child: CircularProgressIndicator()),
              errorWidget: (_, _, _) => const Center(child: Icon(Icons.watch, size: 32)),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    if (hasDiscount)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: AppTheme.accentColor, borderRadius: BorderRadius.circular(4)),
                        child: Text(watch.discountTag ?? '${watch.discountPercentage.toStringAsFixed(0)}% OFF', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                    const Spacer(),
                    IconButton(
                      constraints: const BoxConstraints(),
                      padding: EdgeInsets.zero,
                      icon: Icon(isWishlisted ? Icons.favorite : Icons.favorite_border, color: isWishlisted ? Colors.red : AppTheme.textSecondary, size: 20),
                      onPressed: () => wishlist.toggle(watch),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(watch.brand, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                Text(watch.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Row(
                  children: [
                    ...List.generate(5, (i) => Icon(i < watch.rating.round() ? Icons.star : Icons.star_border, size: 14, color: Colors.amber)),
                    const SizedBox(width: 4),
                    Text('(${watch.reviewCount})', style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text('\$${watch.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.white)),
                    if (hasDiscount) ...[
                      const SizedBox(width: 6),
                      Text('\$${watch.originalPrice.toStringAsFixed(0)}', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary, decoration: TextDecoration.lineThrough)),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
