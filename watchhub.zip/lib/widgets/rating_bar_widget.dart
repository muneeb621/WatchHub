import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class RatingBarWidget extends StatelessWidget {
  final double rating;
  final double itemSize;
  final bool interactive;
  final ValueChanged<double>? onRatingUpdate;

  const RatingBarWidget({
    super.key,
    this.rating = 0,
    this.itemSize = 24,
    this.interactive = false,
    this.onRatingUpdate,
  });

  @override
  Widget build(BuildContext context) {
    return RatingBar.builder(
      initialRating: rating,
      minRating: 1,
      direction: Axis.horizontal,
      allowHalfRating: true,
      itemCount: 5,
      itemSize: itemSize,
      ignoreGestures: !interactive,
      unratedColor: Colors.grey.shade300,
      itemBuilder: (context, index) => const Icon(Icons.star, color: Colors.amber),
      onRatingUpdate: interactive && onRatingUpdate != null ? onRatingUpdate! : (_) {},
    );
  }
}
