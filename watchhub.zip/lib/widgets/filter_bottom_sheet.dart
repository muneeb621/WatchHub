import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/constants.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/providers/watch_provider.dart';

class FilterBottomSheet extends StatefulWidget {
  const FilterBottomSheet({super.key});

  @override
  State<FilterBottomSheet> createState() => _FilterBottomSheetState();
}

class _FilterBottomSheetState extends State<FilterBottomSheet> {
  String? _selectedBrand;
  String? _selectedType;
  double? _minPrice;
  double? _maxPrice;

  @override
  void initState() {
    super.initState();
    final wp = context.read<WatchProvider>();
    _selectedBrand = wp.selectedBrand;
    _selectedType = wp.selectedType;
  }

  void _apply() {
    final wp = context.read<WatchProvider>();
    wp.setBrandFilter(_selectedBrand);
    wp.setTypeFilter(_selectedType);
    if (_minPrice != null || _maxPrice != null) {
      wp.setPriceRange(_minPrice, _maxPrice);
    }
    Navigator.pop(context);
  }

  void _clear() {
    context.read<WatchProvider>().clearFilters();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Filters', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              TextButton(onPressed: _clear, child: const Text('Clear All')),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Brand', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: AppConstants.watchBrands.map((brand) => ChoiceChip(
              label: Text(brand),
              selected: _selectedBrand == brand,
              selectedColor: AppTheme.accentColor.withValues(alpha: 0.3),
              labelStyle: TextStyle(color: _selectedBrand == brand ? AppTheme.accentColor : Colors.white70),
              onSelected: (s) => setState(() => _selectedBrand = s ? brand : null),
            )).toList(),
          ),
          const SizedBox(height: 16),
          const Text('Type', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: AppConstants.watchTypes.map((type) => ChoiceChip(
              label: Text(type),
              selected: _selectedType == type,
              selectedColor: AppTheme.accentColor.withValues(alpha: 0.3),
              labelStyle: TextStyle(color: _selectedType == type ? AppTheme.accentColor : Colors.white70),
              onSelected: (s) => setState(() => _selectedType = s ? type : null),
            )).toList(),
          ),
          const SizedBox(height: 16),
          const Text('Price Range', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Min', hintText: '\$0'),
                  onChanged: (v) => _minPrice = double.tryParse(v),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text('-'),
              ),
              Expanded(
                child: TextField(
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Max', hintText: '\$99999'),
                  onChanged: (v) => _maxPrice = double.tryParse(v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(onPressed: _apply, child: const Text('Apply Filters')),
          ),
        ],
      ),
    );
  }
}
