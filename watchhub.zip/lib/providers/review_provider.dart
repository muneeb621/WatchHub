import 'package:flutter/foundation.dart';
import 'package:watchhub/models/review.dart';
import 'package:watchhub/services/api_service.dart';

class ReviewProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  final Map<String, List<Review>> _reviewsByWatch = {};
  List<Review> _allReviews = [];
  bool _isLoading = false;

  bool get isLoading => _isLoading;

  List<Review> get allReviews => _allReviews;

  List<Review> getReviews(String watchId) {
    return _reviewsByWatch[watchId] ?? [];
  }

  Future<void> fetchReviews(String watchId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final reviews = await _apiService.getReviews(watchId);
      _reviewsByWatch[watchId] = reviews;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchAllReviews() async {
    _allReviews = await _apiService.getAllReviews();
    notifyListeners();
  }

  Future<void> addReview(Review review) async {
    _reviewsByWatch[review.watchId] ??= [];
    _reviewsByWatch[review.watchId]!.insert(0, review);
    _allReviews.insert(0, review);
    await _apiService.addReview(review);
    notifyListeners();
  }

  Future<void> deleteReview(String reviewId) async {
    for (final entry in _reviewsByWatch.entries) {
      entry.value.removeWhere((r) => r.id == reviewId);
    }
    _allReviews.removeWhere((r) => r.id == reviewId);
    await _apiService.deleteReview(reviewId);
    notifyListeners();
  }
}
