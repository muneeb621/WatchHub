import 'package:flutter/foundation.dart' hide Category;
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/models/category.dart';
import 'package:watchhub/services/api_service.dart';

class WatchProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Watch> _watches = [];
  List<Watch> _popularWatches = [];
  List<Watch> _newArrivals = [];
  List<Category> _categories = [];
  bool _isLoading = false;
  String? _error;
  String _currentSort = 'Newest';
  String? _selectedBrand;
  String? _selectedType;
  double? _minPrice;
  double? _maxPrice;
  String _searchQuery = '';

  List<Watch> get watches => _watches;
  List<Watch> get popularWatches => _popularWatches;
  List<Watch> get newArrivals => _newArrivals;
  List<Category> get categories => _categories;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String get currentSort => _currentSort;
  String? get selectedBrand => _selectedBrand;
  String? get selectedType => _selectedType;

  Future<void> loadWatches({bool refresh = false}) async {
    _isLoading = true;
    notifyListeners();
    try {
      _watches = await _apiService.getWatches(
        brand: _selectedBrand,
        type: _selectedType,
        sortBy: _currentSort,
        minPrice: _minPrice,
        maxPrice: _maxPrice,
        searchQuery: _searchQuery,
      );
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadHomeData() async {
    _isLoading = true;
    notifyListeners();
    try {
      final results = await Future.wait([
        _apiService.getPopularWatches(),
        _apiService.getNewArrivals(),
        _apiService.getCategories(),
        _apiService.getWatches(),
      ]);
      _popularWatches = List<Watch>.from(results[0]);
      _newArrivals = List<Watch>.from(results[1]);
      _categories = List<Category>.from(results[2]);
      _watches = List<Watch>.from(results[3]);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Watch> getWatchById(String id) async {
    return _apiService.getWatchById(id);
  }

  void setSort(String sort) {
    _currentSort = sort;
    loadWatches(refresh: true);
  }

  void setBrandFilter(String? brand) {
    _selectedBrand = brand;
    loadWatches(refresh: true);
  }

  void setTypeFilter(String? type) {
    _selectedType = type;
    loadWatches(refresh: true);
  }

  void setPriceRange(double? min, double? max) {
    _minPrice = min;
    _maxPrice = max;
    loadWatches(refresh: true);
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    loadWatches(refresh: true);
  }

  void clearFilters() {
    _selectedBrand = null;
    _selectedType = null;
    _minPrice = null;
    _maxPrice = null;
    _currentSort = 'Newest';
    _searchQuery = '';
    loadWatches(refresh: true);
  }
}
