import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:watchhub/models/cart_item.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/services/api_service.dart';

class CartProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  final List<CartItem> _items = [];

  static const String _storageKey = 'cart_items';

  List<CartItem> get items => List.unmodifiable(_items);
  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);
  double get totalPrice => _items.fold(0.0, (sum, item) => sum + item.totalPrice);

  Future<void> loadCart() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_storageKey);
    if (data != null) {
      final list = jsonDecode(data) as List;
      _items.addAll(list.map((e) => CartItem.fromMap(e as Map<String, dynamic>)));
      notifyListeners();
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_items.map((i) => i.toMap()).toList()));
  }

  void addItem(CartItem item) {
    final index = _items.indexWhere((i) => i.watchId == item.watchId);
    if (index >= 0) {
      _items[index].quantity += item.quantity;
    } else {
      _items.add(item);
    }
    notifyListeners();
    _save();
  }

  void removeItem(String watchId) {
    _items.removeWhere((i) => i.watchId == watchId);
    notifyListeners();
    _save();
  }

  void updateQuantity(String watchId, int quantity) {
    final index = _items.indexWhere((i) => i.watchId == watchId);
    if (index >= 0) {
      if (quantity <= 0) {
        _items.removeAt(index);
      } else {
        _items[index].quantity = quantity;
      }
      notifyListeners();
      _save();
    }
  }

  void clear() {
    _items.clear();
    notifyListeners();
    _save();
  }

  bool isInCart(String watchId) => _items.any((i) => i.watchId == watchId);

  Future<Order> checkout(String shippingAddress, {String? userId}) async {
    final itemsSnapshot = _items.map((i) => OrderItem(
      watchId: i.watchId, watchName: i.watchName,
      watchImage: i.watchImage, price: i.price, quantity: i.quantity,
    )).toList();
    final order = Order(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      userId: userId ?? '',
      items: itemsSnapshot,
      totalAmount: totalPrice,
      shippingAddress: shippingAddress,
    );
    try {
      await _apiService.placeOrder(order.toMap());
      _items.clear();
      notifyListeners();
      _save();
      return order;
    } catch (e) {
      rethrow;
    }
  }
}
