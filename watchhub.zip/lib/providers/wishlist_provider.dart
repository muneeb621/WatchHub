import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:watchhub/models/watch.dart';

class WishlistProvider with ChangeNotifier {
  final List<Watch> _items = [];
  final Map<String, double> _priceAtAdd = {};

  static const String _storageKey = 'wishlist_items';
  static const String _priceKey = 'wishlist_prices';

  List<Watch> get items => List.unmodifiable(_items);
  int get itemCount => _items.length;

  Set<String> get itemsWithPriceDrop {
    final dropped = <String>{};
    for (final item in _items) {
      final savedPrice = _priceAtAdd[item.id];
      if (savedPrice != null && item.price < savedPrice) {
        dropped.add(item.id);
      }
    }
    return dropped;
  }

  bool hasPriceDrop(String watchId) {
    final savedPrice = _priceAtAdd[watchId];
    if (savedPrice == null) return false;
    final watch = _items.where((i) => i.id == watchId);
    if (watch.isEmpty) return false;
    return watch.first.price < savedPrice;
  }

  Future<void> loadWishlist() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_storageKey);
    if (data != null) {
      final list = jsonDecode(data) as List;
      _items.addAll(list.map((e) => Watch.fromMap(e as Map<String, dynamic>)));
    }
    final priceData = prefs.getString(_priceKey);
    if (priceData != null) {
      final decoded = jsonDecode(priceData) as Map;
      for (final entry in decoded.entries) {
        _priceAtAdd[entry.key] = (entry.value as num).toDouble();
      }
    }
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_items.map((i) => i.toMap()).toList()));
    await prefs.setString(_priceKey, jsonEncode(_priceAtAdd));
  }

  void add(Watch watch) {
    if (!_items.any((i) => i.id == watch.id)) {
      _items.add(watch);
      _priceAtAdd[watch.id] = watch.price;
      notifyListeners();
      _save();
    }
  }

  void remove(String watchId) {
    _items.removeWhere((i) => i.id == watchId);
    _priceAtAdd.remove(watchId);
    notifyListeners();
    _save();
  }

  void clear() {
    _items.clear();
    _priceAtAdd.clear();
    notifyListeners();
    _save();
  }

  bool isInWishlist(String watchId) => _items.any((i) => i.id == watchId);

  void toggle(Watch watch) {
    if (isInWishlist(watch.id)) {
      remove(watch.id);
    } else {
      add(watch);
    }
  }
}
