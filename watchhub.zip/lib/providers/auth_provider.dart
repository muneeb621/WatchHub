import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:watchhub/models/user.dart';
import 'package:watchhub/services/auth_service.dart';
import 'package:watchhub/services/firebase_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  User? _user;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isLoggedIn => _user != null;
  bool get isAdmin => _user?.isAdmin ?? false;
  String? get error => _error;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _user = await _authService.login(email, password);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signup(String name, String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _user = await _authService.signup(name, email, password);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> sendPasswordResetEmail(String email) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      await _authService.sendPasswordResetEmail(email);
      return true;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> tryAutoLogin() async {
    _isLoading = true;
    notifyListeners();
    try {
      _user = await _authService.getCurrentUser();
    } catch (_) {
      _user = null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateAvatar(File imageFile) async {
    if (_user == null) return;
    final bytes = await imageFile.readAsBytes();
    final base64Image = base64Encode(bytes);
    final localPath = 'data:image/jpeg;base64,$base64Image';
    _user = _user!.copyWith(avatarUrl: localPath);
    if (FirebaseService.isAvailable && FirebaseService.isFirestoreAvailable) {
      try {
        await FirebaseService.firestore.collection('users').doc(_user!.id).update({'avatarUrl': localPath});
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', jsonEncode(_user!.toMap()));
    notifyListeners();
  }

  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    notifyListeners();
  }

  Future<void> updateUser(User updated) async {
    _user = updated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', jsonEncode(_user!.toMap()));
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
