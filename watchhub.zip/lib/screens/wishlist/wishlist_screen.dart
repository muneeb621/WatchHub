import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/providers/wishlist_provider.dart';
import 'package:watchhub/widgets/watch_card.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final wishlist = context.watch<WishlistProvider>();
    final priceDrops = wishlist.itemsWithPriceDrop;

    return Scaffold(
      appBar: AppBar(title: const Text('Wishlist')),
      body: wishlist.items.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.favorite_outline, size: 80, color: AppTheme.textSecondary),
                  SizedBox(height: 16),
                  Text('Your wishlist is empty', style: TextStyle(fontSize: 18, color: AppTheme.textSecondary)),
                ],
              ),
            )
          : Column(
              children: [
                if (priceDrops.isNotEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    color: AppTheme.successColor.withValues(alpha: 0.15),
                    child: Row(
                      children: [
                        const Icon(Icons.trending_down, color: AppTheme.successColor, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          '${priceDrops.length} item(s) price dropped!',
                          style: const TextStyle(color: AppTheme.successColor, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.65,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: wishlist.items.length,
                    itemBuilder: (_, i) => Stack(
                      children: [
                        WatchCard(watch: wishlist.items[i]),
                        if (wishlist.hasPriceDrop(wishlist.items[i].id))
                          Positioned(
                            top: 4,
                            left: 4,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppTheme.successColor,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text('PRICE DROP', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
