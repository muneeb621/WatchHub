import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/providers/auth_provider.dart';

class ManageAddressesScreen extends StatefulWidget {
  const ManageAddressesScreen({super.key});

  @override
  State<ManageAddressesScreen> createState() => _ManageAddressesScreenState();
}

class _ManageAddressesScreenState extends State<ManageAddressesScreen> {
  final _addressController = TextEditingController();
  final _labelController = TextEditingController();

  void _addAddress() {
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Add Address'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _labelController,
                decoration: const InputDecoration(labelText: 'Label', hintText: 'e.g. Home, Office'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _addressController,
                decoration: const InputDecoration(labelText: 'Address', hintText: 'Full shipping address'),
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                final label = _labelController.text.trim();
                final addr = _addressController.text.trim();
                if (label.isEmpty || addr.isEmpty) return;
                final auth = context.read<AuthProvider>();
                final user = auth.user;
                if (user != null) {
                  auth.updateUser(user.copyWith(
                    shippingAddresses: [...user.shippingAddresses, '$label: $addr'],
                  ));
                }
                _labelController.clear();
                _addressController.clear();
                Navigator.pop(ctx);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _deleteAddress(int index) {
    final auth = context.read<AuthProvider>();
    final user = auth.user;
    if (user != null) {
      final updated = List<String>.from(user.shippingAddresses)..removeAt(index);
      auth.updateUser(user.copyWith(shippingAddresses: updated));
    }
  }

  @override
  void dispose() {
    _addressController.dispose();
    _labelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final addresses = auth.user?.shippingAddresses ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('My Addresses')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ...addresses.asMap().entries.map((entry) => Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.location_on_outlined),
              ),
              title: Text(entry.value.split(':').first, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(entry.value.contains(':') ? entry.value.split(':').skip(1).join(':') : entry.value),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: AppTheme.errorColor),
                onPressed: () => _deleteAddress(entry.key),
              ),
            ),
          )),
          if (addresses.isEmpty)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(
                child: Column(
                  children: [
                    Icon(Icons.location_off_outlined, size: 64, color: AppTheme.textSecondary),
                    SizedBox(height: 16),
                    Text('No addresses saved', style: TextStyle(color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _addAddress,
              icon: const Icon(Icons.add),
              label: const Text('Add New Address'),
            ),
          ),
        ],
      ),
    );
  }
}
