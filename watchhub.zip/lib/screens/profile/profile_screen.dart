import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/l10n/l10n.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/providers/cart_provider.dart';
import 'package:watchhub/providers/theme_provider.dart';
import 'package:watchhub/providers/wishlist_provider.dart';
import 'package:watchhub/services/image_service.dart';
import 'package:watchhub/services/notification_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  void _pickAvatar() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _avatarOption(Icons.photo_library, 'Gallery', () async {
              Navigator.pop(context);
              final file = await ImageService.pickFromGallery();
              if (file != null && mounted) {
                context.read<AuthProvider>().updateAvatar(file);
              }
            }),
            _avatarOption(Icons.camera_alt, 'Camera', () async {
              Navigator.pop(context);
              final file = await ImageService.pickFromCamera();
              if (file != null && mounted) {
                context.read<AuthProvider>().updateAvatar(file);
              }
            }),
          ],
        ),
      ),
    );
  }

  Widget _avatarOption(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppTheme.accentColor.withValues(alpha: 0.15),
            child: Icon(icon, color: AppTheme.accentColor, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final avatarUrl = authProvider.user?.avatarUrl;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _pickAvatar,
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 48,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                      ? (avatarUrl.startsWith('data:')
                          ? MemoryImage(
                              base64Decode(avatarUrl.split(',').last))
                          : NetworkImage(avatarUrl) as ImageProvider)
                      : null,
                  child: avatarUrl == null || avatarUrl.isEmpty
                      ? Text(
                          authProvider.user?.name.isNotEmpty == true
                              ? authProvider.user!.name[0].toUpperCase()
                              : '?',
                          style: const TextStyle(fontSize: 36, color: Colors.white, fontWeight: FontWeight.bold),
                        )
                      : null,
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: AppTheme.accentColor,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.camera_alt, size: 18, color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            authProvider.user?.name ?? 'Guest',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          Text(
            authProvider.user?.email ?? '',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 32),
          _buildMenuItem(context, Icons.receipt_long_outlined, 'Order History', () => Navigator.pushNamed(context, AppRoutes.orderHistory)),
          _buildMenuItem(context, Icons.favorite_outline, 'Wishlist', () => Navigator.pushNamed(context, AppRoutes.wishlist)),
          _buildMenuItem(context, Icons.local_shipping_outlined, 'Track Order', () => Navigator.pushNamed(context, '/track-order')),
          _buildMenuItem(context, Icons.location_on_outlined, 'My Addresses', () => Navigator.pushNamed(context, '/addresses')),
          if (authProvider.isAdmin)
            _buildMenuItem(context, Icons.admin_panel_settings_outlined, 'Admin Panel', () => Navigator.pushNamed(context, AppRoutes.adminDashboard)),
          _buildMenuItem(context, Icons.headset_mic_outlined, 'Support', () => Navigator.pushNamed(context, AppRoutes.support)),
          _buildMenuItem(context, Icons.help_outline, 'FAQ', () => Navigator.pushNamed(context, AppRoutes.faq)),
          _buildThemeToggle(context),
          _buildLanguageToggle(context),
          _buildNotificationToggle(context),
          _buildMenuItem(context, Icons.info_outline, 'About', () => _showAboutDialog(context)),
          if (authProvider.isLoggedIn) ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  context.read<CartProvider>().clear();
                  context.read<WishlistProvider>().clear();
                  authProvider.logout();
                  Navigator.pushNamedAndRemoveUntil(context, AppRoutes.login, (route) => false);
                },
                icon: const Icon(Icons.logout, color: AppTheme.errorColor),
                label: const Text('Logout', style: TextStyle(color: AppTheme.errorColor)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppTheme.errorColor),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildThemeToggle(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: SwitchListTile(
        secondary: Icon(themeProvider.isDarkMode ? Icons.dark_mode : Icons.light_mode, color: AppTheme.accentColor),
        title: const Text('Dark Mode'),
        value: themeProvider.isDarkMode,
        onChanged: (_) => themeProvider.toggleTheme(),
        activeThumbColor: AppTheme.accentColor,
      ),
    );
  }

  Widget _buildLanguageToggle(BuildContext context) {
    final langProvider = context.watch<LanguageProvider>();
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: SwitchListTile(
        secondary: Icon(langProvider.isUrdu ? Icons.language : Icons.translate, color: AppTheme.accentColor),
        title: Text(langProvider.isUrdu ? 'Language: Urdu' : 'Language: English'),
        subtitle: Text(langProvider.isUrdu ? 'Switch to English' : 'Urdu mein badlein', style: const TextStyle(fontSize: 12)),
        value: langProvider.isUrdu,
        onChanged: (_) => langProvider.toggleLanguage(),
        activeThumbColor: AppTheme.accentColor,
      ),
    );
  }

  Widget _buildNotificationToggle(BuildContext context) {
    final notifService = context.watch<NotificationService>();
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: SwitchListTile(
        secondary: const Icon(Icons.notifications_outlined, color: AppTheme.accentColor),
        title: const Text('Push Notifications'),
        subtitle: const Text('Order updates & offers', style: TextStyle(fontSize: 12)),
        value: notifService.notificationsEnabled,
        onChanged: (v) => notifService.setNotificationsEnabled(v),
        activeThumbColor: AppTheme.accentColor,
      ),
    );
  }

  Widget _buildMenuItem(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: AppTheme.primaryColor),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardColor,
        title: const Text('About WatchHub'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Icon(Icons.watch, size: 64, color: AppTheme.accentColor),
            ),
            SizedBox(height: 16),
            Text('WatchHub v1.0.0',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('A premium watch shopping mobile app.',
              style: TextStyle(color: AppTheme.textSecondary)),
            SizedBox(height: 16),
            Text('Features:', style: TextStyle(fontWeight: FontWeight.w600)),
            SizedBox(height: 4),
            Text('• Browse luxury watches\n• Add to cart & wishlist\n• User reviews & ratings\n• Order tracking\n• Admin management',
              style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
