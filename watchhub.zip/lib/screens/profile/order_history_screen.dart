import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/services/api_service.dart';
import 'package:watchhub/services/tracking_service.dart';
import 'package:watchhub/utils/helpers.dart';

class OrderHistoryScreen extends StatefulWidget {
  final bool trackOnly;

  const OrderHistoryScreen({super.key, this.trackOnly = false});

  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  final ApiService _api = ApiService();
  final TrackingService _tracking = TrackingService();
  late List<Order> _orders;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tracking.addListener(_onTrackingUpdate);
    _loadOrders();
  }

  @override
  void dispose() {
    _tracking.removeListener(_onTrackingUpdate);
    _tracking.stopListening();
    super.dispose();
  }

  void _onTrackingUpdate() {
    if (mounted) setState(() {});
  }

  Color _statusColor(OrderStatus status) {
    switch (status) {
      case OrderStatus.pending: return Colors.orange;
      case OrderStatus.confirmed: return Colors.blue;
      case OrderStatus.shipped: return AppTheme.accentColor;
      case OrderStatus.delivered: return AppTheme.successColor;
      case OrderStatus.cancelled: return AppTheme.errorColor;
    }
  }

  void _loadOrders() {
    setState(() => _loading = true);
    final userId = context.read<AuthProvider>().user?.id;
    var orders = _api.getOrders(userId: userId);
    if (widget.trackOnly) {
      orders = orders.where((o) => o.status != OrderStatus.delivered && o.status != OrderStatus.cancelled).toList();
    }
    _orders = orders;
    for (final o in orders) {
      if (widget.trackOnly || o.status != OrderStatus.delivered) {
        _tracking.checkOrderStatus(o.id);
      }
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Order History')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _orders.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.receipt_long_outlined, size: 80, color: AppTheme.textSecondary),
                      SizedBox(height: 16),
                      Text('No orders yet', style: TextStyle(fontSize: 18, color: AppTheme.textSecondary)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () async => _loadOrders(),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _orders.length,
                    itemBuilder: (_, i) => _buildOrderCard(_orders[i]),
                  ),
                ),
    );
  }

  Widget _buildOrderCard(Order order) {
    final step = order.status.index;
    final steps = ['Pending', 'Confirmed', 'Shipped', 'Delivered'];

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        initiallyExpanded: widget.trackOnly,
        leading: Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: _statusColor(order.status),
            shape: BoxShape.circle,
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text('#${order.id.toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _statusColor(order.status).withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                order.statusText,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: _statusColor(order.status)),
              ),
            ),
          ],
        ),
        subtitle: Text(
          '${Helpers.formatDate(order.createdAt)}  \$${order.totalAmount.toStringAsFixed(2)}',
          style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
        ),
        children: [
          ...order.items.map((item) => ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(item.watchImage, width: 48, height: 48, fit: BoxFit.cover, errorBuilder: (_, _, _) => const Icon(Icons.watch)),
            ),
            title: Text(item.watchName, style: const TextStyle(fontSize: 14)),
            subtitle: Text('Qty: ${item.quantity} x \$${item.price.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12)),
            trailing: Text('\$${item.totalPrice.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
          )),
          if (order.status != OrderStatus.cancelled) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: _buildTrackingProgress(steps, step),
            ),
          ],
          if (order.trackingNumber != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Row(
                children: [
                  const Icon(Icons.local_shipping_outlined, size: 16, color: AppTheme.textSecondary),
                  const SizedBox(width: 6),
                  Text('Tracking: ${order.trackingNumber}', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                ],
              ),
            ),
          if (order.status == OrderStatus.pending)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Cancel Order'),
                        content: const Text('Are you sure you want to cancel this order?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
                          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Yes, Cancel')),
                        ],
                      ),
                    );
                    if (confirm == true) {
                      await ApiService().updateOrderStatus(order.id, OrderStatus.cancelled);
                      _loadOrders();
                    }
                  },
                  icon: const Icon(Icons.cancel_outlined, size: 18),
                  label: const Text('Cancel Order'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.errorColor,
                    side: const BorderSide(color: AppTheme.errorColor),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildTrackingProgress(List<String> steps, int currentStep) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Tracking Progress', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textSecondary)),
        const SizedBox(height: 8),
        Row(
          children: List.generate(steps.length * 2 - 1, (i) {
            if (i.isOdd) {
              return Expanded(
                child: Container(
                  height: 3,
                  color: i ~/ 2 < currentStep ? AppTheme.accentColor : Colors.grey.withValues(alpha: 0.3),
                ),
              );
            }
            final idx = i ~/ 2;
            final isActive = idx <= currentStep;
            final isCurrent = idx == currentStep && currentStep < 3;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: isCurrent ? 28 : 20,
                  height: isCurrent ? 28 : 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isActive ? AppTheme.accentColor : Colors.grey.withValues(alpha: 0.2),
                    border: isCurrent ? Border.all(color: AppTheme.accentColor, width: 2) : null,
                  ),
                  child: isActive
                      ? (idx < currentStep
                          ? const Icon(Icons.check, size: 12, color: Colors.black)
                          : Text('${idx + 1}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.black)))
                      : null,
                ),
                const SizedBox(height: 2),
                Text(steps[idx], style: TextStyle(fontSize: 8, color: isActive ? AppTheme.accentColor : Colors.grey)),
              ],
            );
          }),
        ),
      ],
    );
  }
}
