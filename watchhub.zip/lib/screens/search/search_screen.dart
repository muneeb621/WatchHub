import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/constants.dart';
import 'package:watchhub/providers/watch_provider.dart';
import 'package:watchhub/widgets/watch_card.dart';
import 'package:watchhub/widgets/search_bar_widget.dart';
import 'package:watchhub/widgets/filter_bottom_sheet.dart';
import 'package:watchhub/widgets/shimmer_loading.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _searchController = TextEditingController();
  String _selectedSort = AppConstants.sortOptions[0];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearch(String query) {
    context.read<WatchProvider>().setSearchQuery(query);
  }

  void _onSortChanged(String? sort) {
    if (sort != null) {
      setState(() => _selectedSort = sort);
      context.read<WatchProvider>().setSort(sort);
    }
  }

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => const FilterBottomSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final watchProvider = context.watch<WatchProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Search Watches')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: SearchBarWidget(
                    controller: _searchController,
                    onSubmitted: _onSearch,
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.filter_list),
                  onPressed: _showFilterSheet,
                ),
                const SizedBox(width: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedSort,
                      items: AppConstants.sortOptions.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 13)))).toList(),
                      onChanged: _onSortChanged,
                      isDense: true,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: watchProvider.isLoading
                ? const Padding(
                    padding: EdgeInsets.all(12),
                    child: ShimmerGrid(count: 6, aspectRatio: 0.65),
                  )
                : watchProvider.watches.isEmpty
                    ? const Center(child: Text('No watches found'))
                    : GridView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.65,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        itemCount: watchProvider.watches.length,
                        itemBuilder: (_, i) => WatchCard(watch: watchProvider.watches[i]),
                      ),
          ),
        ],
      ),
    );
  }
}
