import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/providers/cart_provider.dart';
import 'package:watchhub/providers/watch_provider.dart';
import 'package:watchhub/widgets/watch_card.dart';
import 'package:watchhub/widgets/shimmer_loading.dart';
import 'package:watchhub/widgets/animated_bottom_nav.dart';
import 'package:watchhub/screens/cart/cart_screen.dart';
import 'package:watchhub/screens/profile/profile_screen.dart';
import 'package:watchhub/screens/search/search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _tabs = const [
    _HomeTab(),
    SearchScreen(),
    CartScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<WatchProvider>().loadHomeData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _tabs,
      ),
      bottomNavigationBar: AnimatedBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final watchProvider = context.watch<WatchProvider>();
    final cartProvider = context.watch<CartProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('WatchHub'),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined),
                onPressed: () => Navigator.pushNamed(context, AppRoutes.cart),
              ),
              if (cartProvider.itemCount > 0)
                Positioned(
                  right: 4,
                  top: 4,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${cartProvider.itemCount}',
                      style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: watchProvider.isLoading
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: ShimmerGrid(count: 6),
            )
          : RefreshIndicator(
              onRefresh: () => context.read<WatchProvider>().loadHomeData(),
              child: ListView(
                children: [
                  _buildCategoryChips(context, watchProvider),
                  if (watchProvider.popularWatches.isNotEmpty) ...[
                    _buildSectionHeader(context, 'Popular Watches'),
                    SizedBox(
                      height: 240,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: watchProvider.popularWatches.length.clamp(0, 8),
                        itemBuilder: (_, i) => SizedBox(
                          width: 200,
                          child: WatchCard(watch: watchProvider.popularWatches[i]),
                        ),
                      ),
                    ),
                  ],
                  if (watchProvider.newArrivals.isNotEmpty) ...[
                    _buildSectionHeader(context, 'New Arrivals'),
                    SizedBox(
                      height: 240,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: watchProvider.newArrivals.length.clamp(0, 8),
                        itemBuilder: (_, i) => SizedBox(
                          width: 200,
                          child: WatchCard(watch: watchProvider.newArrivals[i]),
                        ),
                      ),
                    ),
                  ],
                  _buildSectionHeader(context, 'All Watches'),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.77,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemCount: watchProvider.watches.length,
                    itemBuilder: (_, i) => WatchCard(watch: watchProvider.watches[i]),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
    );
  }

  Widget _buildCategoryChips(BuildContext context, WatchProvider watchProvider) {
    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        children: [
          _buildChip(context, 'All', null, watchProvider),
          ...watchProvider.categories.map((cat) => _buildChip(context, cat.name, cat.id, watchProvider)),
        ],
      ),
    );
  }

  Widget _buildChip(BuildContext context, String label, String? id, WatchProvider watchProvider) {
    final isSelected = id == null ? watchProvider.selectedType == null : watchProvider.selectedType == label;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (_) => context.read<WatchProvider>().setTypeFilter(isSelected ? null : label),
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          TextButton(
            onPressed: () => Navigator.pushNamed(context, AppRoutes.search),
            child: const Text('See All'),
          ),
        ],
      ),
    );
  }
}
