import 'package:flutter/material.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/user.dart';
import 'package:watchhub/services/api_service.dart';

class ManageUsersScreen extends StatefulWidget {
  const ManageUsersScreen({super.key});

  @override
  State<ManageUsersScreen> createState() => _ManageUsersScreenState();
}

class _ManageUsersScreenState extends State<ManageUsersScreen> {
  final ApiService _api = ApiService();
  List<User> _users = [];
  List<User> _filtered = [];
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _load() {
    setState(() {
      _users = _api.getAllUsers();
      _applyFilter();
    });
  }

  void _applyFilter() {
    setState(() {
      if (_search.isEmpty) {
        _filtered = List.from(_users);
      } else {
        final q = _search.toLowerCase();
        _filtered = _users.where((u) =>
          u.name.toLowerCase().contains(q) ||
          u.email.toLowerCase().contains(q) ||
          (u.phone?.toLowerCase().contains(q) ?? false)
        ).toList();
      }
    });
  }

  void _showUserForm({User? user}) {
    final nameCtrl = TextEditingController(text: user?.name ?? '');
    final emailCtrl = TextEditingController(text: user?.email ?? '');
    final phoneCtrl = TextEditingController(text: user?.phone ?? '');
    final isAdmin = ValueNotifier(user?.isAdmin ?? false);
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(user != null ? 'Edit User' : 'Add User'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name'), validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                const SizedBox(height: 8),
                TextFormField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email'), keyboardType: TextInputType.emailAddress, validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                const SizedBox(height: 8),
                TextFormField(controller: phoneCtrl, decoration: const InputDecoration(labelText: 'Phone'), keyboardType: TextInputType.phone),
                const SizedBox(height: 8),
                ValueListenableBuilder(
                  valueListenable: isAdmin,
                  builder: (_, v, _) => CheckboxListTile(
                    title: const Text('Admin'), value: v,
                    onChanged: (val) => isAdmin.value = val ?? false,
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              final userData = User(
                id: user?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
                name: nameCtrl.text,
                email: emailCtrl.text,
                phone: phoneCtrl.text,
                isAdmin: isAdmin.value,
              );
              if (user != null) {
                await _api.updateUser(user.id, userData.toMap());
              } else {
                await _api.addUser(userData);
              }
              _load();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(user != null ? 'Update' : 'Add'),
          ),
        ],
      ),
    );
  }

  void _toggleAdmin(User user) async {
    await _api.updateUser(user.id, {'isAdmin': !user.isAdmin});
    _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${user.name} is ${!user.isAdmin ? "now" : "no longer"} an admin'),
          backgroundColor: AppTheme.successColor,
        ),
      );
    }
  }

  void _deleteUser(User user) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete User'),
        content: Text('Delete "${user.name}" permanently?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              await _api.deleteUser(user.id);
              _load();
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${user.name} deleted'), backgroundColor: AppTheme.successColor),
                );
              }
            },
            child: const Text('Delete', style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final adminCount = _users.where((u) => u.isAdmin).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Users'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () => _showUserForm()),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                _buildMiniStat('Total', '${_users.length}', Colors.blue),
                const SizedBox(width: 12),
                _buildMiniStat('Admins', '$adminCount', AppTheme.accentColor),
                const SizedBox(width: 12),
                _buildMiniStat('Users', '${_users.length - adminCount}', Colors.green),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search users...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _search.isNotEmpty
                    ? IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () { _searchCtrl.clear(); _search = ''; _applyFilter(); })
                    : null,
              ),
              onChanged: (v) { _search = v; _applyFilter(); },
            ),
          ),
          Expanded(
            child: _filtered.isEmpty
                ? const Center(child: Text('No users', style: TextStyle(fontSize: 16)))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    itemCount: _filtered.length,
                    itemBuilder: (_, i) {
                      final user = _filtered[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: user.isAdmin ? AppTheme.accentColor : Colors.blueGrey,
                            child: Text(user.name[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          ),
                          title: Row(
                            children: [
                              Expanded(child: Text(user.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
                              if (user.isAdmin)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(color: AppTheme.accentColor.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(8)),
                                  child: const Text('Admin', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppTheme.accentColor)),
                                ),
                            ],
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(user.email, style: const TextStyle(fontSize: 12)),
                              if (user.phone != null) Text(user.phone!, style: const TextStyle(fontSize: 12)),
                              Text('Joined ${user.createdAt.day}/${user.createdAt.month}/${user.createdAt.year}', style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(user.isAdmin ? Icons.admin_panel_settings : Icons.person_outline, size: 20, color: user.isAdmin ? AppTheme.accentColor : null),
                                onPressed: () => _toggleAdmin(user),
                                tooltip: user.isAdmin ? 'Remove admin' : 'Make admin',
                              ),
                              IconButton(icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _showUserForm(user: user)),
                              IconButton(icon: const Icon(Icons.delete_outline, size: 20, color: AppTheme.errorColor), onPressed: () => _deleteUser(user)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniStat(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}
