import 'package:flutter/material.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/models/user.dart' as app;
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/services/api_service.dart';

class ManageOrdersScreen extends StatefulWidget {
  const ManageOrdersScreen({super.key});

  @override
  State<ManageOrdersScreen> createState() => _ManageOrdersScreenState();
}

class _ManageOrdersScreenState extends State<ManageOrdersScreen> {
  final ApiService _api = ApiService();
  List<Order> _orders = [];
  List<Order> _filtered = [];
  List<Watch> _watches = [];
  List<app.User> _users = [];
  String _statusFilter = 'All';
  final _searchCtrl = TextEditingController();
  String _search = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _orders = _api.getOrders(); _users = _api.getAllUsers(); });
    _watches = await _api.getWatches();
    _applyFilter();
  }

  void _applyFilter() {
    setState(() {
      _filtered = List.from(_orders);
      if (_statusFilter != 'All') {
        final status = OrderStatus.values.firstWhere(
          (s) => s.name[0].toUpperCase() + s.name.substring(1) == _statusFilter,
          orElse: () => OrderStatus.pending,
        );
        _filtered = _filtered.where((o) => o.status == status).toList();
      }
      if (_search.isNotEmpty) {
        final q = _search.toLowerCase();
        _filtered = _filtered.where((o) =>
          o.id.toLowerCase().contains(q) ||
          o.shippingAddress.toLowerCase().contains(q) ||
          o.items.any((item) => item.watchName.toLowerCase().contains(q))
        ).toList();
      }
    });
  }

  Future<void> _updateStatus(Order order, OrderStatus newStatus) async {
    await _api.updateOrderStatus(order.id, newStatus);
    _load();
  }

  Future<void> _editTracking(Order order) async {
    final ctrl = TextEditingController(text: order.trackingNumber ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tracking Number'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Enter tracking number', labelText: 'Tracking #'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (result != null && result.isNotEmpty) {
      await _api.updateOrderTracking(order.id, result);
      _load();
    }
  }

  void _showCreateOrderDialog() {
    final selectedUser = ValueNotifier<app.User?>(null);
    final selectedWatches = ValueNotifier<Map<String, int>>({});
    final addressCtrl = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create Order'),
        content: SizedBox(
          width: 400,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Select User', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  const SizedBox(height: 4),
                  ValueListenableBuilder(
                    valueListenable: selectedUser,
                    builder: (_, user, _) => DropdownButtonFormField<app.User>(
                      initialValue: user,
                      decoration: const InputDecoration(hintText: 'Choose a user'),
                      items: _users.map((u) => DropdownMenuItem(value: u, child: Text('${u.name} (${u.email})', style: const TextStyle(fontSize: 13)))).toList(),
                      onChanged: (v) => selectedUser.value = v,
                      validator: (v) => v == null ? 'Select a user' : null,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text('Select Watches', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  const SizedBox(height: 4),
                  ..._watches.map((w) => ValueListenableBuilder(
                    valueListenable: selectedWatches,
                    builder: (_, map, _) {
                      final qty = map[w.id] ?? 0;
                      return CheckboxListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        title: Text(w.name, style: const TextStyle(fontSize: 12)),
                        subtitle: Text('\$${w.price.toStringAsFixed(2)}', style: const TextStyle(fontSize: 11)),
                        value: qty > 0,
                        onChanged: (val) {
                          final m = Map<String, int>.from(map);
                          if (val == true) {
                            m[w.id] = 1;
                          } else {
                            m.remove(w.id);
                          }
                          selectedWatches.value = m;
                        },
                      );
                    },
                  )),
                  if (selectedWatches.value.isNotEmpty)
                    ...selectedWatches.value.entries.map((e) {
                      final watch = _watches.firstWhere((w) => w.id == e.key);
                      return ValueListenableBuilder(
                        valueListenable: selectedWatches,
                        builder: (_, map, _) => Padding(
                          padding: const EdgeInsets.only(left: 32, bottom: 4),
                          child: Row(
                            children: [
                              Text('${watch.name}: ', style: const TextStyle(fontSize: 12)),
                              IconButton(
                                icon: const Icon(Icons.remove_circle_outline, size: 18),
                                onPressed: () {
                                  final m = Map<String, int>.from(map);
                                  if ((m[e.key] ?? 0) > 1) {
                                    m[e.key] = m[e.key]! - 1;
                                  } else {
                                    m.remove(e.key);
                                  }
                                  selectedWatches.value = m;
                                },
                              ),
                              Text('${map[e.key] ?? 0}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                              IconButton(
                                icon: const Icon(Icons.add_circle_outline, size: 18),
                                onPressed: () {
                                  final m = Map<String, int>.from(map);
                                  m[e.key] = (m[e.key] ?? 0) + 1;
                                  selectedWatches.value = m;
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: addressCtrl,
                    decoration: const InputDecoration(labelText: 'Shipping Address'),
                    maxLines: 2,
                    validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              if (selectedWatches.value.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Select at least one watch'), backgroundColor: AppTheme.errorColor),
                );
                return;
              }
              final user = selectedUser.value!;
              final items = selectedWatches.value.entries.map((e) {
                final watch = _watches.firstWhere((w) => w.id == e.key);
                return OrderItem(
                  watchId: watch.id,
                  watchName: watch.name,
                  watchImage: watch.images.first,
                  price: watch.price,
                  quantity: e.value,
                );
              }).toList();
              final total = items.fold(0.0, (s, i) => s + i.totalPrice);
              final order = Order(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                userId: user.id,
                items: items,
                totalAmount: total,
                shippingAddress: addressCtrl.text,
              );
              await _api.placeOrder(order.toMap());
              _load();
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Order created'), backgroundColor: AppTheme.successColor),
                );
              }
            },
            child: const Text('Create Order'),
          ),
        ],
      ),
    );
  }

  String _orderCountText() {
    if (_statusFilter == 'All') return '${_orders.length} total';
    return '${_filtered.length} ${_statusFilter.toLowerCase()}';
  }

  Color _statusColor(OrderStatus status) {
    switch (status) {
      case OrderStatus.pending: return Colors.orange;
      case OrderStatus.confirmed: return Colors.blue;
      case OrderStatus.shipped: return AppTheme.accentColor;
      case OrderStatus.delivered: return AppTheme.successColor;
      case OrderStatus.cancelled: return AppTheme.errorColor;
    }
  }

  List<OrderStatus> _nextStatuses(OrderStatus current) {
    if (current == OrderStatus.cancelled || current == OrderStatus.delivered) return [];
    return OrderStatus.values.where((s) => s.index > current.index && s != OrderStatus.cancelled).toList();
  }

  @override
  Widget build(BuildContext context) {
    final statuses = ['All', ...OrderStatus.values.map((s) => s.name[0].toUpperCase() + s.name.substring(1))];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Orders'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: _showCreateOrderDialog, tooltip: 'Create Order'),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search by order ID, address, or product...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _search.isNotEmpty
                    ? IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () { _searchCtrl.clear(); _search = ''; _applyFilter(); })
                    : null,
              ),
              onChanged: (v) { _search = v; _applyFilter(); },
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: statuses.map((s) => Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: Text(s, style: const TextStyle(fontSize: 12)),
                  selected: _statusFilter == s,
                  onSelected: (_) { setState(() { _statusFilter = s; }); _applyFilter(); },
                  selectedColor: _statusFilter == s ? _statusColorForName(s)?.withValues(alpha: 0.3) : null,
                ),
              )).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Text(_orderCountText(), style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.refresh, size: 20),
                  onPressed: _load,
                  tooltip: 'Refresh',
                ),
              ],
            ),
          ),
          Expanded(
            child: _filtered.isEmpty
                ? const Center(child: Text('No orders', style: TextStyle(fontSize: 16)))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    itemCount: _filtered.length,
                    itemBuilder: (_, i) {
                      final order = _filtered[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: ExpansionTile(
                          leading: Container(
                            width: 12, height: 12,
                            decoration: BoxDecoration(color: _statusColor(order.status), shape: BoxShape.circle),
                          ),
                          title: Text('#${order.id.toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          subtitle: Text('\$${order.totalAmount.toStringAsFixed(2)}  |  ${order.createdAt.day}/${order.createdAt.month}/${order.createdAt.year}', style: const TextStyle(fontSize: 12)),
                          children: [
                            ...order.items.map((item) => ListTile(
                              dense: true,
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(item.watchImage, width: 40, height: 40, fit: BoxFit.cover, errorBuilder: (_, _, _) => const Icon(Icons.watch)),
                              ),
                              title: Text(item.watchName, style: const TextStyle(fontSize: 13)),
                              subtitle: Text('Qty: ${item.quantity}', style: const TextStyle(fontSize: 11)),
                              trailing: Text('\$${item.totalPrice.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            )),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Shipping: ${order.shippingAddress}', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                                  InkWell(
                                    onTap: () => _editTracking(order),
                                    child: Row(
                                      children: [
                                        Icon(Icons.local_shipping, size: 14, color: order.trackingNumber != null ? AppTheme.accentColor : AppTheme.textSecondary),
                                        const SizedBox(width: 4),
                                        Text(
                                          order.trackingNumber ?? 'Add tracking number',
                                          style: TextStyle(fontSize: 12, color: order.trackingNumber != null ? AppTheme.accentColor : AppTheme.textSecondary),
                                        ),
                                        const SizedBox(width: 4),
                                        Icon(Icons.edit, size: 12, color: AppTheme.textSecondary),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: _statusColor(order.status).withValues(alpha: 0.2),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(order.statusText, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12, color: _statusColor(order.status))),
                                      ),
                                      const Spacer(),
                                      if (_nextStatuses(order.status).isNotEmpty)
                                        ..._nextStatuses(order.status).map((s) => Padding(
                                          padding: const EdgeInsets.only(left: 4),
                                          child: SizedBox(
                                            height: 32,
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12)),
                                              onPressed: () => _updateStatus(order, s),
                                              child: Text('Mark $s', style: const TextStyle(fontSize: 11)),
                                            ),
                                          ),
                                        )),
                                      if (order.status == OrderStatus.pending)
                                        Padding(
                                          padding: const EdgeInsets.only(left: 4),
                                          child: SizedBox(
                                            height: 32,
                                            child: OutlinedButton(
                                              style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12), side: const BorderSide(color: AppTheme.errorColor)),
                                              onPressed: () => _updateStatus(order, OrderStatus.cancelled),
                                              child: const Text('Cancel', style: TextStyle(fontSize: 11, color: AppTheme.errorColor)),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Color? _statusColorForName(String name) {
    switch (name) {
      case 'Pending': return Colors.orange;
      case 'Confirmed': return Colors.blue;
      case 'Shipped': return AppTheme.accentColor;
      case 'Delivered': return AppTheme.successColor;
      case 'Cancelled': return AppTheme.errorColor;
      default: return null;
    }
  }
}
