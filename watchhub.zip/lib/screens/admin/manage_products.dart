import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/services/api_service.dart';
import 'package:watchhub/services/image_service.dart';

class ManageProductsScreen extends StatefulWidget {
  const ManageProductsScreen({super.key});

  @override
  State<ManageProductsScreen> createState() => _ManageProductsScreenState();
}

class _ManageProductsScreenState extends State<ManageProductsScreen> {
  final ApiService _api = ApiService();
  List<Watch> _watches = [];
  List<Watch> _filtered = [];
  bool _loading = true;
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _watches = await _api.getWatches();
    _applyFilter();
    setState(() => _loading = false);
  }

  void _applyFilter() {
    setState(() {
      if (_search.isEmpty) {
        _filtered = List.from(_watches);
      } else {
        final q = _search.toLowerCase();
        _filtered = _watches.where((w) =>
          w.name.toLowerCase().contains(q) ||
          w.brand.toLowerCase().contains(q) ||
          w.type.toLowerCase().contains(q)
        ).toList();
      }
    });
  }

  void _deleteWatch(Watch watch) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Product'),
        content: Text('Delete "${watch.name}" permanently?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              await _api.deleteWatch(watch.id);
              _watches.removeWhere((w) => w.id == watch.id);
              _applyFilter();
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${watch.name} deleted'), backgroundColor: AppTheme.successColor),
                );
              }
            },
            child: const Text('Delete', style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );
  }

  void _showProductForm({Watch? watch}) {
    final nameCtrl = TextEditingController(text: watch?.name ?? '');
    final brandCtrl = TextEditingController(text: watch?.brand ?? '');
    final typeCtrl = TextEditingController(text: watch?.type ?? '');
    final descCtrl = TextEditingController(text: watch?.description ?? '');
    final priceCtrl = TextEditingController(text: watch?.price.toString() ?? '');
    final originalPriceCtrl = TextEditingController(text: watch?.originalPrice.toString() ?? '');
    final stockCtrl = TextEditingController(text: watch?.stock.toString() ?? '');
    final imageUrlCtrl = TextEditingController(text: watch?.images.isNotEmpty == true ? watch!.images.first : '');
    final isPopular = ValueNotifier(watch?.isPopular ?? false);
    final isNewArrival = ValueNotifier(watch?.isNewArrival ?? false);
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(watch != null ? 'Edit Product' : 'Add Product'),
        content: SizedBox(
          width: 400,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name'), validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                  const SizedBox(height: 8),
                  TextFormField(controller: brandCtrl, decoration: const InputDecoration(labelText: 'Brand'), validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                  const SizedBox(height: 8),
                  TextFormField(controller: typeCtrl, decoration: const InputDecoration(labelText: 'Type'), validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                  const SizedBox(height: 8),
                  TextFormField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Description'), maxLines: 3),
                  const SizedBox(height: 8),
                  TextFormField(controller: priceCtrl, decoration: const InputDecoration(labelText: 'Price'), keyboardType: TextInputType.number, validator: (v) => v == null || double.tryParse(v) == null ? 'Invalid price' : null),
                  const SizedBox(height: 8),
                  TextFormField(controller: originalPriceCtrl, decoration: const InputDecoration(labelText: 'Original Price (0 = no discount)'), keyboardType: TextInputType.number),
                  const SizedBox(height: 8),
                  TextFormField(controller: stockCtrl, decoration: const InputDecoration(labelText: 'Stock'), keyboardType: TextInputType.number, validator: (v) => v == null || int.tryParse(v) == null ? 'Invalid stock' : null),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(controller: imageUrlCtrl, decoration: const InputDecoration(labelText: 'Image URL'), validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        icon: const Icon(Icons.image_outlined),
                        onPressed: () async {
                          final file = await ImageService.pickFromGallery();
                          if (file != null) {
                            final bytes = await file.readAsBytes();
                            imageUrlCtrl.text = 'data:image/jpeg;base64,${base64Encode(bytes)}';
                          }
                        },
                        tooltip: 'Pick from gallery',
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ValueListenableBuilder(
                    valueListenable: isPopular,
                    builder: (_, v, _) => CheckboxListTile(
                      title: const Text('Popular'), value: v,
                      onChanged: (val) => isPopular.value = val ?? false,
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  ValueListenableBuilder(
                    valueListenable: isNewArrival,
                    builder: (_, v, _) => CheckboxListTile(
                      title: const Text('New Arrival'), value: v,
                      onChanged: (val) => isNewArrival.value = val ?? false,
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              final watchData = Watch(
                id: watch?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
                name: nameCtrl.text,
                brand: brandCtrl.text,
                type: typeCtrl.text,
                description: descCtrl.text,
                price: double.parse(priceCtrl.text),
                originalPrice: double.tryParse(originalPriceCtrl.text) ?? 0,
                stock: int.parse(stockCtrl.text),
                rating: watch?.rating ?? 0,
                reviewCount: watch?.reviewCount ?? 0,
                images: [imageUrlCtrl.text],
                specifications: watch?.specifications ?? [],
                isPopular: isPopular.value,
                isNewArrival: isNewArrival.value,
                discountTag: double.tryParse(originalPriceCtrl.text) != null && double.parse(originalPriceCtrl.text) > double.parse(priceCtrl.text)
                    ? '${((double.parse(originalPriceCtrl.text) - double.parse(priceCtrl.text)) / double.parse(originalPriceCtrl.text) * 100).round()}% OFF'
                    : null,
              );
              if (watch != null) {
                await _api.updateWatch(watch.id, watchData.toMap());
              } else {
                await _api.addWatch(watchData);
              }
              await _load();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(watch != null ? 'Update' : 'Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Products'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () => _showProductForm()),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _search.isNotEmpty
                    ? IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () { _searchCtrl.clear(); _search = ''; _applyFilter(); })
                    : null,
              ),
              onChanged: (v) { _search = v; _applyFilter(); },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('No products', style: TextStyle(fontSize: 16)))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: _filtered.length,
                          itemBuilder: (_, i) {
                            final watch = _filtered[i];
                            return Card(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              child: ListTile(
                                leading: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(watch.images.first, width: 48, height: 48, fit: BoxFit.cover, errorBuilder: (_, _, _) => const Icon(Icons.watch)),
                                ),
                                title: Text(watch.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                                subtitle: Text('\$${watch.price.toStringAsFixed(2)}  |  Stock: ${watch.stock}  |  ${watch.brand}', style: const TextStyle(fontSize: 12)),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _showProductForm(watch: watch)),
                                    IconButton(icon: const Icon(Icons.delete_outline, size: 20, color: AppTheme.errorColor), onPressed: () => _deleteWatch(watch)),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
