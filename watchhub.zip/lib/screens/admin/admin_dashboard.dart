import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/order.dart';
import 'package:watchhub/models/user.dart' as app;
import 'package:watchhub/providers/watch_provider.dart';
import 'package:watchhub/providers/review_provider.dart';
import 'package:watchhub/services/api_service.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final ApiService _api = ApiService();
  List<Order> _orders = [];
  List<app.User> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    setState(() {
      _orders = _api.getOrders();
      _users = _api.getAllUsers();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final watchProvider = context.watch<WatchProvider>();
    final reviews = context.watch<ReviewProvider>();

    final totalProducts = watchProvider.watches.length;
    final totalOrders = _orders.length;
    final totalUsers = _users.length;
    final totalReviews = reviews.allReviews.length;
    final pendingOrders = _orders.where((o) => o.status == OrderStatus.pending).length;
    final adminCount = _users.where((u) => u.isAdmin).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: () { setState(() => _loading = true); _load(); }),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async { setState(() => _loading = true); _load(); },
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(child: _StatCard(icon: Icons.inventory_2, label: 'Products', value: '$totalProducts', color: Colors.blue)),
                      const SizedBox(width: 12),
                      Expanded(child: _StatCard(icon: Icons.receipt_long, label: 'Orders', value: '$totalOrders', color: Colors.orange)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _StatCard(icon: Icons.people, label: 'Users', value: '$totalUsers', color: Colors.green)),
                      const SizedBox(width: 12),
                      Expanded(child: _StatCard(icon: Icons.rate_review, label: 'Reviews', value: '$totalReviews', color: Colors.purple)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(child: _MiniStat(label: 'Pending Orders', value: '$pendingOrders', color: Colors.orange)),
                      const SizedBox(width: 12),
                      Expanded(child: _MiniStat(label: 'Admins', value: '$adminCount', color: Colors.amber)),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text('Manage', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 12),
                  _buildMenuItem(context, Icons.inventory_2_outlined, 'Manage Products', 'View, add, edit & delete products', AppRoutes.adminProducts, Colors.blue),
                  _buildMenuItem(context, Icons.people_outlined, 'Manage Users', 'View, add, edit & manage users', AppRoutes.adminUsers, Colors.green),
                  _buildMenuItem(context, Icons.receipt_long_outlined, 'Manage Orders', 'Track & update order statuses', AppRoutes.adminOrders, Colors.orange),
                  _buildMenuItem(context, Icons.rate_review_outlined, 'Manage Reviews', 'Moderate user reviews', AppRoutes.adminReviews, Colors.purple),
                ],
              ),
            ),
    );
  }

  Widget _buildMenuItem(BuildContext context, IconData icon, String title, String subtitle, String route, Color color) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withValues(alpha: 0.15), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.pushNamed(context, route),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _StatCard({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }
}
