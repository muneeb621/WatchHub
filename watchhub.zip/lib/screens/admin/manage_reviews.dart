import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/review.dart';
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/providers/review_provider.dart';
import 'package:watchhub/services/api_service.dart';

class ManageReviewsScreen extends StatefulWidget {
  const ManageReviewsScreen({super.key});

  @override
  State<ManageReviewsScreen> createState() => _ManageReviewsScreenState();
}

class _ManageReviewsScreenState extends State<ManageReviewsScreen> {
  final ApiService _api = ApiService();
  List<Review> _reviews = [];
  List<Review> _filtered = [];
  final Map<String, String> _watchNames = {};
  bool _loading = true;
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final results = await Future.wait([
      _api.getAllReviews(),
      _api.getWatches(),
    ]);
    _reviews = results[0] as List<Review>;
    final watches = results[1] as List<Watch>;
    _watchNames.clear();
    for (final w in watches) {
      _watchNames[w.id] = w.name;
    }
    _applyFilter();
    setState(() => _loading = false);
  }

  void _applyFilter() {
    setState(() {
      if (_search.isEmpty) {
        _filtered = List.from(_reviews);
      } else {
        final q = _search.toLowerCase();
        _filtered = _reviews.where((r) =>
          r.userName.toLowerCase().contains(q) ||
          r.comment.toLowerCase().contains(q) ||
          r.watchId.contains(q)
        ).toList();
      }
    });
  }

  void _deleteReview(Review review) async {
    await context.read<ReviewProvider>().deleteReview(review.id);
    _reviews.removeWhere((r) => r.id == review.id);
    _applyFilter();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Review deleted'), backgroundColor: AppTheme.successColor),
      );
    }
  }

  String _watchNameForId(String watchId) {
    return _watchNames[watchId] ?? 'Watch #$watchId';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Manage Reviews')),
      body: Column(
        children: [
          if (!_loading)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  _buildMiniStat('Total', _reviews.length.toString(), Colors.purple),
                  const SizedBox(width: 12),
                  _buildMiniStat('Avg Rating', _reviews.isEmpty ? '0' : (_reviews.map((r) => r.rating).reduce((a, b) => a + b) / _reviews.length).toStringAsFixed(1), Colors.amber),
                  const SizedBox(width: 12),
                  _buildMiniStat('Filtered', _filtered.length.toString(), Colors.blueGrey),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search by user, comment, or watch...',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _search.isNotEmpty
                    ? IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () { _searchCtrl.clear(); _search = ''; _applyFilter(); })
                    : null,
              ),
              onChanged: (v) { _search = v; _applyFilter(); },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('No reviews', style: TextStyle(fontSize: 16)))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: _filtered.length,
                          itemBuilder: (_, i) {
                            final review = _filtered[i];
                            return Card(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: Colors.purple.withValues(alpha: 0.2),
                                  child: Text(review.userName[0].toUpperCase(), style: const TextStyle(color: Colors.purple, fontWeight: FontWeight.bold)),
                                ),
                                title: Row(
                                  children: [
                                    Text(review.userName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                                    const SizedBox(width: 8),
                                    ...List.generate(5, (j) => Icon(
                                      j < review.rating ? Icons.star : Icons.star_border,
                                      size: 14, color: AppTheme.accentColor,
                                    )),
                                  ],
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(review.comment, style: const TextStyle(fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                                    const SizedBox(height: 2),
                                    Text(_watchNameForId(review.watchId), style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
                                  ],
                                ),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 20, color: AppTheme.errorColor),
                                  onPressed: () => _deleteReview(review),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniStat(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}
