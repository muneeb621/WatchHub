import 'package:flutter/material.dart';

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  static const _faqs = [
    {'q': 'What is your return policy?', 'a': 'We offer a 30-day return policy for all unworn watches in original condition.'},
    {'q': 'How long does shipping take?', 'a': 'Standard shipping takes 5-7 business days. Express shipping is available for 2-3 business days.'},
    {'q': 'Do you offer warranty?', 'a': 'All watches come with a 2-year manufacturer warranty.'},
    {'q': 'Can I cancel my order?', 'a': 'Orders can be cancelled within 24 hours of placing them.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FAQ')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _faqs.length,
        separatorBuilder: (_, _) => const Divider(),
        itemBuilder: (_, i) => ExpansionTile(
          title: Text(_faqs[i]['q']!, style: const TextStyle(fontWeight: FontWeight.w600)),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Text(_faqs[i]['a']!, style: const TextStyle(fontSize: 14)),
            ),
          ],
        ),
      ),
    );
  }
}
