import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/feedback_item.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/services/api_service.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final _issueTitleController = TextEditingController();
  final _issueDescController = TextEditingController();
  String _issueCategory = 'Bug Report';
  bool _submitting = false;

  @override
  void dispose() {
    _issueTitleController.dispose();
    _issueDescController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Support')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSupportItem(context, Icons.chat_outlined, 'Live Chat', 'Chat with our support team', () => _showLiveChat(context)),
          _buildSupportItem(context, Icons.email_outlined, 'Email Us', 'support@watchhub.com', () => _showEmailDialog(context)),
          _buildSupportItem(context, Icons.phone_outlined, 'Call Us', '+1 (555) 123-4567', () => _showPhoneDialog(context)),
          _buildSupportItem(context, Icons.help_outline, 'FAQ', 'Frequently asked questions', () => Navigator.pushNamed(context, AppRoutes.faq)),
          const Divider(height: 32),
          const Text('Report an Issue', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),
          _buildIssueForm(context),
        ],
      ),
    );
  }

  Widget _buildIssueForm(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              initialValue: _issueCategory,
              decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'Bug Report', child: Text('Bug Report')),
                DropdownMenuItem(value: 'Feature Request', child: Text('Feature Request')),
                DropdownMenuItem(value: 'Account Issue', child: Text('Account Issue')),
                DropdownMenuItem(value: 'Payment Problem', child: Text('Payment Problem')),
                DropdownMenuItem(value: 'Other', child: Text('Other')),
              ],
              onChanged: (v) => setState(() => _issueCategory = v!),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _issueTitleController,
              decoration: const InputDecoration(labelText: 'Title', hintText: 'Brief summary of the issue', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _issueDescController,
              decoration: const InputDecoration(labelText: 'Description', hintText: 'Describe the issue in detail...', border: OutlineInputBorder()),
              maxLines: 4,
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitting ? null : _submitIssue,
                child: _submitting
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Submit Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _submitIssue() async {
    final title = _issueTitleController.text.trim();
    final desc = _issueDescController.text.trim();
    if (title.isEmpty || desc.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in both title and description')),
      );
      return;
    }
    setState(() => _submitting = true);
    try {
      final user = context.read<AuthProvider>().user;
      await ApiService().addFeedback(FeedbackItem(
        category: _issueCategory,
        title: title,
        description: desc,
        userEmail: user?.email ?? 'guest@watchhub.com',
        createdAt: DateTime.now(),
      ));
      if (!mounted) return;
      _issueTitleController.clear();
      _issueDescController.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Thank you! Your report has been submitted.'), backgroundColor: AppTheme.successColor),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to submit. Please try again.'), backgroundColor: AppTheme.errorColor),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showLiveChat(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.chat, size: 48, color: AppTheme.accentColor),
            const SizedBox(height: 16),
            const Text('Live Chat', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Our support team is available\nMon-Fri, 9AM-6PM EST.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textSecondary)),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Connecting to support agent...')),
                  );
                },
                child: const Text('Start Chat'),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showEmailDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardColor,
        title: const Text('Email Us'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Send your inquiry to:'),
            SizedBox(height: 8),
            Text('support@watchhub.com',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.accentColor)),
            SizedBox(height: 12),
            Text('We typically respond within 24 hours.',
              style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Clipboard.setData(const ClipboardData(text: 'support@watchhub.com'));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Email address copied to clipboard!')),
              );
            },
            child: const Text('Copy Email'),
          ),
        ],
      ),
    );
  }

  void _showPhoneDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardColor,
        title: const Text('Call Us'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Call our support team at:'),
            SizedBox(height: 8),
            Text('+1 (555) 123-4567',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.accentColor)),
            SizedBox(height: 12),
            Text('Mon-Fri, 9AM-6PM EST.',
              style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
          ElevatedButton(
            onPressed: () {
              Clipboard.setData(const ClipboardData(text: '+1 (555) 123-4567'));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Phone number copied to clipboard!')),
              );
            },
            child: const Text('Copy Number'),
          ),
        ],
      ),
    );
  }

  Widget _buildSupportItem(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon, color: AppTheme.primaryColor),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
