import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/providers/cart_provider.dart';
import 'package:watchhub/screens/cart/payment_screen.dart';
import 'package:watchhub/widgets/cart_item_card.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  void _showCheckoutDialog(BuildContext context) {
    final auth = context.read<AuthProvider>();
    final savedAddresses = auth.user?.shippingAddresses ?? [];
    final addressController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Checkout'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (savedAddresses.isNotEmpty) ...[
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'Saved Addresses'),
                  items: savedAddresses.map((a) => DropdownMenuItem(
                    value: a,
                    child: Text(a.contains(':') ? a.split(':').first : a, style: const TextStyle(fontSize: 13)),
                  )).toList(),
                  onChanged: (v) {
                    setDialogState(() {
                      addressController.text = v?.contains(':') == true ? v!.split(':').skip(1).join(':').trim() : v ?? '';
                    });
                  },
                ),
                const SizedBox(height: 12),
                const Divider(),
                const SizedBox(height: 4),
              ],
              TextField(
                controller: addressController,
                decoration: const InputDecoration(
                  labelText: 'Shipping Address',
                  hintText: 'Enter your full address',
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                icon: const Icon(Icons.add, size: 16),
                label: const Text('Save this address'),
                onPressed: () {
                  final addr = addressController.text.trim();
                  if (addr.isNotEmpty && auth.user != null) {
                    auth.updateUser(auth.user!.copyWith(
                      shippingAddresses: [...auth.user!.shippingAddresses, 'New: $addr'],
                    ));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Address saved!')),
                    );
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (addressController.text.trim().isEmpty) return;
                Navigator.pop(ctx);
                if (!context.mounted) return;
                final amount = context.read<CartProvider>().totalPrice;
                final paid = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(builder: (_) => PaymentScreen(amount: amount)),
                );
                if (paid == true && context.mounted) {
                  await context.read<CartProvider>().checkout(addressController.text.trim());
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Order placed successfully!'),
                        backgroundColor: AppTheme.successColor,
                      ),
                    );
                  }
                }
              },
              child: const Text('Proceed to Payment'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = context.watch<CartProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Shopping Cart')),
      body: cartProvider.items.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shopping_cart_outlined, size: 80, color: AppTheme.textSecondary),
                  SizedBox(height: 16),
                  Text('Your cart is empty', style: TextStyle(fontSize: 18, color: AppTheme.textSecondary)),
                ],
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cartProvider.items.length,
                    itemBuilder: (_, i) {
                      final item = cartProvider.items[i];
                      return CartItemCard(
                        item: item,
                        onIncrement: () => cartProvider.updateQuantity(item.watchId, item.quantity + 1),
                        onDecrement: () => cartProvider.updateQuantity(item.watchId, item.quantity - 1),
                        onDelete: () => cartProvider.removeItem(item.watchId),
                      );
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.cardColor,
                    boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0, -2))],
                  ),
                  child: SafeArea(
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('Total', style: TextStyle(fontSize: 14, color: AppTheme.textSecondary)),
                              Text('\$${cartProvider.totalPrice.toStringAsFixed(2)}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold, color: AppTheme.primaryColor)),
                            ],
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () => _showCheckoutDialog(context),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                          ),
                          child: const Text('Checkout'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
