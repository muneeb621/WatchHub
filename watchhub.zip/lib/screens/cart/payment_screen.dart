import 'package:flutter/material.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/services/payment_service.dart';

class PaymentScreen extends StatefulWidget {
  final double amount;

  const PaymentScreen({super.key, required this.amount});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _cardController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvvController = TextEditingController();
  final _nameController = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _cardController.dispose();
    _expiryController.dispose();
    _cvvController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  void _pay() async {
    final card = _cardController.text.trim();
    final expiry = _expiryController.text.trim();
    final cvv = _cvvController.text.trim();
    final name = _nameController.text.trim();

    if (card.isEmpty || expiry.isEmpty || cvv.isEmpty || name.isEmpty) {
      setState(() => _error = 'All fields are required');
      return;
    }

    final expiryParts = expiry.split('/');
    if (expiryParts.length != 2) {
      setState(() => _error = 'Invalid expiry (MM/YY)');
      return;
    }

    if (!PaymentService.validateCardNumber(card)) {
      setState(() => _error = 'Invalid card number');
      return;
    }

    if (!PaymentService.validateExpiry(expiryParts[0], '20${expiryParts[1]}')) {
      setState(() => _error = 'Card expired or invalid');
      return;
    }

    if (!PaymentService.validateCVV(cvv)) {
      setState(() => _error = 'Invalid CVV');
      return;
    }

    setState(() { _loading = true; _error = null; });

    final result = await PaymentService().simulatePayment(
      amount: widget.amount,
      cardholderName: name,
    );

    if (!mounted) return;
    setState(() => _loading = false);

    if (result.success) {
      Navigator.pop(context, true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Payment successful!'), backgroundColor: AppTheme.successColor),
      );
    } else {
      setState(() => _error = result.error ?? 'Payment failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.credit_card, size: 64, color: AppTheme.accentColor),
            const SizedBox(height: 8),
            Text('\$${widget.amount.toStringAsFixed(2)}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Cardholder Name', prefixIcon: Icon(Icons.person_outline)),
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _cardController,
              decoration: const InputDecoration(labelText: 'Card Number', prefixIcon: Icon(Icons.credit_card_outlined), hintText: '1234 5678 9012 3456'),
              keyboardType: TextInputType.number,
              maxLength: 19,
              onChanged: (v) {
                final formatted = PaymentService.formatCardNumber(v.replaceAll(RegExp(r'\D'), ''));
                if (formatted != v) {
                  _cardController.value = TextEditingValue(text: formatted, selection: TextSelection.collapsed(offset: formatted.length));
                }
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: TextField(
                  controller: _expiryController,
                  decoration: const InputDecoration(labelText: 'MM/YY', hintText: '12/28'),
                  keyboardType: TextInputType.datetime,
                  maxLength: 5,
                  onChanged: (v) {
                    if (v.length == 2 && !v.contains('/')) {
                      _expiryController.text = '$v/';
                      _expiryController.selection = TextSelection.collapsed(offset: _expiryController.text.length);
                    }
                  },
                )),
                const SizedBox(width: 12),
                Expanded(child: TextField(
                  controller: _cvvController,
                  decoration: const InputDecoration(labelText: 'CVV', hintText: '123'),
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  obscureText: true,
                )),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: AppTheme.errorColor, fontSize: 13)),
            ],
            const SizedBox(height: 24),
            SizedBox(
              height: 48,
              child: ElevatedButton(
                onPressed: _loading ? null : _pay,
                child: _loading ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : const Text('Pay Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
