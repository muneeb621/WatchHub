import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';
import 'package:share_plus/share_plus.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/models/watch.dart';
import 'package:watchhub/models/cart_item.dart';
import 'package:watchhub/models/review.dart';
import 'package:watchhub/providers/cart_provider.dart';
import 'package:watchhub/providers/wishlist_provider.dart';
import 'package:watchhub/providers/review_provider.dart';
import 'package:watchhub/widgets/review_card.dart';
import 'package:watchhub/widgets/rating_bar_widget.dart';

class ProductDetailScreen extends StatefulWidget {
  final Watch watch;

  const ProductDetailScreen({super.key, required this.watch});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  final int _selectedImageIndex = 0;
  int _reviewDialogRating = 5;
  String _reviewSortBy = 'Most Recent';
  final _reviewCommentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ReviewProvider>().fetchReviews(widget.watch.id);
    });
  }

  @override
  void dispose() {
    _reviewCommentController.dispose();
    super.dispose();
  }

  void _showImageZoom() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            iconTheme: const IconThemeData(color: Colors.white),
          ),
          body: Center(
            child: PhotoView(
              imageProvider: NetworkImage(widget.watch.images[_selectedImageIndex]),
              minScale: PhotoViewComputedScale.contained,
              maxScale: PhotoViewComputedScale.covered * 2,
              backgroundDecoration: const BoxDecoration(color: Colors.black),
            ),
          ),
        ),
      ),
    );
  }

  void _showWriteReviewDialog() {
    _reviewDialogRating = 5;
    _reviewCommentController.clear();
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Write a Review'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RatingBarWidget(
                rating: _reviewDialogRating.toDouble(),
                interactive: true,
                itemSize: 36,
                onRatingUpdate: (v) => setDialogState(() => _reviewDialogRating = v.round()),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _reviewCommentController,
                decoration: const InputDecoration(
                  labelText: 'Your review',
                  hintText: 'Share your experience...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 4,
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (_reviewCommentController.text.trim().isEmpty) return;
                final review = Review(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  watchId: widget.watch.id,
                  userId: '',
                  userName: 'You',
                  rating: _reviewDialogRating.toDouble(),
                  comment: _reviewCommentController.text.trim(),
                );
                await context.read<ReviewProvider>().addReview(review);
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Review added!'), backgroundColor: AppTheme.successColor),
                    );
                  }
                }
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }

  List<Review> _sortedReviews(List<Review> reviews) {
    final sorted = List<Review>.from(reviews);
    switch (_reviewSortBy) {
      case 'Highest Rated':
        sorted.sort((a, b) => b.rating.compareTo(a.rating));
        break;
      case 'Lowest Rated':
        sorted.sort((a, b) => a.rating.compareTo(b.rating));
        break;
      case 'Most Helpful':
        sorted.sort((a, b) => b.helpfulCount.compareTo(a.helpfulCount));
        break;
      default:
        sorted.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }
    return sorted;
  }

  @override
  Widget build(BuildContext context) {
    final watch = widget.watch;
    final wishlist = context.watch<WishlistProvider>();
    final cart = context.watch<CartProvider>();
    final reviewProvider = context.watch<ReviewProvider>();
    final isWishlisted = wishlist.isInWishlist(watch.id);
    final hasDiscount = watch.originalPrice > watch.price;

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverAppBar(
            expandedHeight: 320,
            pinned: true,
            actions: [
              IconButton(
                icon: const Icon(Icons.share_outlined),
                onPressed: () {
                  final watch = widget.watch;
                  SharePlus.instance.share(
                    ShareParams(
                      text: 'Check out this ${watch.name} by ${watch.brand} — \$${watch.price.toStringAsFixed(0)} at WatchHub!\n\n${watch.images.first}',
                    ),
                  );
                },
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  GestureDetector(
                    onTap: _showImageZoom,
                    child: CachedNetworkImage(
                      imageUrl: watch.images[_selectedImageIndex],
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 320,
                      placeholder: (_, _) => const Center(child: CircularProgressIndicator()),
                      errorWidget: (_, _, _) => const Center(child: Icon(Icons.watch, size: 64)),
                    ),
                  ),
                  if (watch.images.length > 1)
                    Positioned(
                      bottom: 8,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(watch.images.length, (i) => Container(
                              width: 8,
                              height: 8,
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: i == _selectedImageIndex ? Colors.white : Colors.white38,
                              ),
                            )),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(watch.brand, style: const TextStyle(fontSize: 14, color: AppTheme.textSecondary, letterSpacing: 1)),
                      const SizedBox(height: 4),
                      Text(watch.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(isWishlisted ? Icons.favorite : Icons.favorite_border, color: isWishlisted ? Colors.red : AppTheme.textSecondary),
                  onPressed: () => wishlist.toggle(watch),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text('\$${watch.price.toStringAsFixed(2)}', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold, color: Colors.white)),
                if (hasDiscount) ...[
                  const SizedBox(width: 8),
                  Text('\$${watch.originalPrice.toStringAsFixed(2)}', style: const TextStyle(fontSize: 16, color: AppTheme.textSecondary, decoration: TextDecoration.lineThrough)),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: AppTheme.accentColor, borderRadius: BorderRadius.circular(4)),
                    child: Text(watch.discountTag ?? '${watch.discountPercentage.toStringAsFixed(0)}% OFF', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                RatingBarWidget(rating: watch.rating, itemSize: 20),
                const SizedBox(width: 8),
                Text('${watch.rating} (${watch.reviewCount} reviews)', style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(watch.inStock ? Icons.check_circle : Icons.cancel, size: 18, color: watch.inStock ? AppTheme.successColor : AppTheme.errorColor),
                const SizedBox(width: 6),
                Text(watch.inStock ? 'In Stock (${watch.stock} available)' : 'Out of Stock', style: TextStyle(fontSize: 14, color: watch.inStock ? AppTheme.successColor : AppTheme.errorColor)),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Description', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            Text(watch.description, style: const TextStyle(fontSize: 14, height: 1.5, color: AppTheme.textSecondary)),
            const SizedBox(height: 24),
            const Text('Specifications', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            ...watch.specifications.map((spec) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.check, size: 16, color: AppTheme.primaryColor),
                  const SizedBox(width: 8),
                  Expanded(child: Text(spec, style: const TextStyle(fontSize: 14, color: AppTheme.textSecondary))),
                ],
              ),
            )),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Reviews', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Row(
                  children: [
                    DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _reviewSortBy,
                        items: const [
                          DropdownMenuItem(value: 'Most Recent', child: Text('Most Recent', style: TextStyle(fontSize: 12))),
                          DropdownMenuItem(value: 'Highest Rated', child: Text('Highest Rated', style: TextStyle(fontSize: 12))),
                          DropdownMenuItem(value: 'Lowest Rated', child: Text('Lowest Rated', style: TextStyle(fontSize: 12))),
                          DropdownMenuItem(value: 'Most Helpful', child: Text('Most Helpful', style: TextStyle(fontSize: 12))),
                        ],
                        onChanged: (v) => setState(() => _reviewSortBy = v!),
                        isDense: true,
                        style: const TextStyle(fontSize: 12, color: AppTheme.primaryColor),
                      ),
                    ),
                    const SizedBox(width: 8),
                    TextButton.icon(
                      icon: const Icon(Icons.edit, size: 18),
                      label: const Text('Write'),
                      onPressed: _showWriteReviewDialog,
                    ),
                  ],
                ),
              ],
            ),
            if (reviewProvider.isLoading)
              const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
            else
              ..._sortedReviews(reviewProvider.getReviews(watch.id)).map((review) => ReviewCard(review: review)),
            if (reviewProvider.getReviews(watch.id).isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('No reviews yet. Be the first to review!', style: TextStyle(color: AppTheme.textSecondary))),
              ),
            const SizedBox(height: 80),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () {
                final cartItem = CartItem(
                  id: watch.id,
                  watchId: watch.id,
                  watchName: watch.name,
                  watchImage: watch.images.first,
                  price: watch.price,
                );
                cart.addItem(cartItem);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${watch.name} added to cart'),
                    action: SnackBarAction(
                      label: 'View Cart',
                      textColor: Colors.white,
                      onPressed: () => Navigator.pushNamed(context, AppRoutes.cart),
                    ),
                  ),
                );
              },
              icon: const Icon(Icons.add_shopping_cart),
              label: Text(cart.isInCart(watch.id) ? 'Add More to Cart' : 'Add to Cart'),
            ),
          ),
        ),
      ),
    );
  }
}
