import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppLocalization {
  final Locale locale;
  late Map<String, dynamic> _strings;

  AppLocalization(this.locale);

  static AppLocalization? of(BuildContext context) {
    return Localizations.of<AppLocalization>(context, AppLocalization);
  }

  static const LocalizationDelegate delegate = LocalizationDelegate();

  Future<void> load() async {
    final code = locale.languageCode;
    try {
      final path = 'assets/l10n/app_$code.arb';
      final file = File(path);
      if (await file.exists()) {
        final content = await file.readAsString();
        _strings = jsonDecode(content);
      } else {
        _strings = {};
      }
    } catch (_) {
      _strings = {};
    }
  }

  String translate(String key, [Map<String, String>? params]) {
    final value = _strings[key] as String?;
    if (value == null) return key;
    if (params == null) return value;
    var result = value;
    params.forEach((k, v) => result = result.replaceAll('{$k}', v));
    return result;
  }
}

class LocalizationDelegate extends LocalizationsDelegate<AppLocalization> {
  const LocalizationDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'ur'].contains(locale.languageCode);

  @override
  Future<AppLocalization> load(Locale locale) async {
    final localization = AppLocalization(locale);
    await localization.load();
    return localization;
  }

  @override
  bool shouldReload(LocalizationDelegate old) => false;
}

class LanguageProvider with ChangeNotifier {
  Locale _locale = const Locale('en');
  Locale get locale => _locale;
  bool get isUrdu => _locale.languageCode == 'ur';

  LanguageProvider() {
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString('language_code') ?? 'en';
    _locale = Locale(code);
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    _locale = Locale(code);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language_code', code);
    notifyListeners();
  }

  Future<void> toggleLanguage() async {
    if (_locale.languageCode == 'en') {
      await setLanguage('ur');
    } else {
      await setLanguage('en');
    }
  }
}
