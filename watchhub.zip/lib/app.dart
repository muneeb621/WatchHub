import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:watchhub/config/routes.dart';
import 'package:watchhub/config/theme.dart';
import 'package:watchhub/l10n/l10n.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/providers/theme_provider.dart';
import 'package:watchhub/screens/auth/login_screen.dart';
import 'package:watchhub/screens/auth/onboarding_screen.dart';
import 'package:watchhub/screens/home/home_screen.dart';

class WatchHubApp extends StatelessWidget {
  const WatchHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WatchHub',
      debugShowCheckedModeBanner: false,
      locale: context.watch<LanguageProvider>().locale,
      localizationsDelegates: const [
        AppLocalization.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en'),
        Locale('ur'),
      ],
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: context.watch<ThemeProvider>().themeMode,
      home: FutureBuilder<bool>(
        future: SharedPreferences.getInstance().then((p) => p.getBool('onboarding_seen') ?? false),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (!snapshot.data!) {
            return const OnboardingScreen();
          }
          return Consumer<AuthProvider>(
            builder: (context, auth, _) {
              if (auth.isLoading) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }
              if (auth.isLoggedIn) {
                return const HomeScreen();
              }
              return const LoginScreen();
            },
          );
        },
      ),
      onGenerateRoute: AppRoutes.generateRoute,
    );
  }
}
