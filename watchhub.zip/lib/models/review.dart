class Review {
  final String id;
  final String watchId;
  final String userId;
  final String userName;
  final String? userAvatar;
  final double rating;
  final String comment;
  final DateTime createdAt;
  final int helpfulCount;

  Review({
    required this.id,
    required this.watchId,
    required this.userId,
    required this.userName,
    this.userAvatar,
    required this.rating,
    required this.comment,
    DateTime? createdAt,
    this.helpfulCount = 0,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
    'id': id, 'watchId': watchId, 'userId': userId,
    'userName': userName, 'userAvatar': userAvatar,
    'rating': rating, 'comment': comment, 'helpfulCount': helpfulCount,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Review.fromMap(Map<String, dynamic> map) => Review(
    id: map['id'] ?? '',
    watchId: map['watchId'] ?? '',
    userId: map['userId'] ?? '',
    userName: map['userName'] ?? '',
    userAvatar: map['userAvatar'],
    rating: (map['rating'] ?? 0).toDouble(),
    comment: map['comment'] ?? '',
    helpfulCount: map['helpfulCount'] ?? 0,
    createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : null,
  );
}
