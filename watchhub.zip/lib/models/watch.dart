class Watch {
  final String id;
  final String name;
  final String brand;
  final String type;
  final String description;
  final double price;
  final double originalPrice;
  final double rating;
  final int reviewCount;
  final int stock;
  final List<String> images;
  final List<String> specifications;
  final bool isPopular;
  final bool isNewArrival;
  final String? discountTag;

  Watch({
    required this.id,
    required this.name,
    required this.brand,
    required this.type,
    required this.description,
    required this.price,
    this.originalPrice = 0,
    this.rating = 0,
    this.reviewCount = 0,
    this.stock = 0,
    required this.images,
    this.specifications = const [],
    this.isPopular = false,
    this.isNewArrival = false,
    this.discountTag,
  });

  double get discountPercentage =>
      originalPrice > 0 ? ((originalPrice - price) / originalPrice * 100).roundToDouble() : 0;

  bool get inStock => stock > 0;

  Map<String, dynamic> toMap() => {
    'id': id, 'name': name, 'brand': brand, 'type': type,
    'description': description, 'price': price, 'originalPrice': originalPrice,
    'rating': rating, 'reviewCount': reviewCount, 'stock': stock,
    'images': images, 'specifications': specifications,
    'isPopular': isPopular, 'isNewArrival': isNewArrival, 'discountTag': discountTag,
  };

  factory Watch.fromMap(Map<String, dynamic> map) => Watch(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    brand: map['brand'] ?? '',
    type: map['type'] ?? '',
    description: map['description'] ?? '',
    price: (map['price'] ?? 0).toDouble(),
    originalPrice: (map['originalPrice'] ?? 0).toDouble(),
    rating: (map['rating'] ?? 0).toDouble(),
    reviewCount: map['reviewCount'] ?? 0,
    stock: map['stock'] ?? 0,
    images: List<String>.from(map['images'] ?? []),
    specifications: List<String>.from(map['specifications'] ?? []),
    isPopular: map['isPopular'] ?? false,
    isNewArrival: map['isNewArrival'] ?? false,
    discountTag: map['discountTag'],
  );
}
