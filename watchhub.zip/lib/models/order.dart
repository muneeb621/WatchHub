enum OrderStatus { pending, confirmed, shipped, delivered, cancelled }

class Order {
  final String id;
  final String userId;
  final List<OrderItem> items;
  final double totalAmount;
  final String shippingAddress;
  final OrderStatus status;
  final DateTime createdAt;
  final DateTime? deliveredAt;
  final String? trackingNumber;

  Order({
    required this.id,
    required this.userId,
    required this.items,
    required this.totalAmount,
    required this.shippingAddress,
    this.status = OrderStatus.pending,
    DateTime? createdAt,
    this.deliveredAt,
    this.trackingNumber,
  }) : createdAt = createdAt ?? DateTime.now();

  String get statusText {
    switch (status) {
      case OrderStatus.pending: return 'Pending';
      case OrderStatus.confirmed: return 'Confirmed';
      case OrderStatus.shipped: return 'Shipped';
      case OrderStatus.delivered: return 'Delivered';
      case OrderStatus.cancelled: return 'Cancelled';
    }
  }

  Map<String, dynamic> toMap() => {
    'id': id, 'userId': userId, 'items': items.map((e) => e.toMap()).toList(),
    'totalAmount': totalAmount, 'shippingAddress': shippingAddress,
    'status': status.index, 'createdAt': createdAt.toIso8601String(),
    'trackingNumber': trackingNumber, 'deliveredAt': deliveredAt?.toIso8601String(),
  };

  factory Order.fromMap(Map<String, dynamic> map) => Order(
    id: map['id'] ?? '',
    userId: map['userId'] ?? '',
    items: (map['items'] as List).map((e) => OrderItem.fromMap(e)).toList(),
    totalAmount: (map['totalAmount'] ?? 0).toDouble(),
    shippingAddress: map['shippingAddress'] ?? '',
    status: OrderStatus.values[map['status'] ?? 0],
    createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : null,
    deliveredAt: map['deliveredAt'] != null ? DateTime.parse(map['deliveredAt']) : null,
    trackingNumber: map['trackingNumber'],
  );
}

class OrderItem {
  final String watchId;
  final String watchName;
  final String watchImage;
  final double price;
  final int quantity;

  OrderItem({
    required this.watchId,
    required this.watchName,
    required this.watchImage,
    required this.price,
    required this.quantity,
  });

  double get totalPrice => price * quantity;

  Map<String, dynamic> toMap() => {
    'watchId': watchId, 'watchName': watchName,
    'watchImage': watchImage, 'price': price, 'quantity': quantity,
  };

  factory OrderItem.fromMap(Map<String, dynamic> map) => OrderItem(
    watchId: map['watchId'] ?? '',
    watchName: map['watchName'] ?? '',
    watchImage: map['watchImage'] ?? '',
    price: (map['price'] ?? 0).toDouble(),
    quantity: map['quantity'] ?? 1,
  );
}
