class CartItem {
  final String id;
  final String watchId;
  final String watchName;
  final String watchImage;
  final double price;
  int quantity;

  CartItem({
    required this.id,
    required this.watchId,
    required this.watchName,
    required this.watchImage,
    required this.price,
    this.quantity = 1,
  });

  double get totalPrice => price * quantity;

  Map<String, dynamic> toMap() => {
    'id': id, 'watchId': watchId, 'watchName': watchName,
    'watchImage': watchImage, 'price': price, 'quantity': quantity,
  };

  factory CartItem.fromMap(Map<String, dynamic> map) => CartItem(
    id: map['id'] ?? '',
    watchId: map['watchId'] ?? '',
    watchName: map['watchName'] ?? '',
    watchImage: map['watchImage'] ?? '',
    price: (map['price'] ?? 0).toDouble(),
    quantity: map['quantity'] ?? 1,
  );
}
