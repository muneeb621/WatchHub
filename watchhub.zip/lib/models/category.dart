class Category {
  final String id;
  final String name;
  final String imageUrl;

  Category({required this.id, required this.name, required this.imageUrl});

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'imageUrl': imageUrl};

  factory Category.fromMap(Map<String, dynamic> map) => Category(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    imageUrl: map['imageUrl'] ?? '',
  );
}
