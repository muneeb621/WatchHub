class User {
  final String id;
  final String email;
  final String name;
  final String? phone;
  final String? avatarUrl;
  final List<String> shippingAddresses;
  final DateTime createdAt;
  final bool isAdmin;

  User({
    required this.id,
    required this.email,
    required this.name,
    this.phone,
    this.avatarUrl,
    this.shippingAddresses = const [],
    DateTime? createdAt,
    this.isAdmin = false,
  }) : createdAt = createdAt ?? DateTime.now();

  User copyWith({
    String? id,
    String? email,
    String? name,
    String? phone,
    String? avatarUrl,
    List<String>? shippingAddresses,
    DateTime? createdAt,
    bool? isAdmin,
  }) => User(
    id: id ?? this.id,
    email: email ?? this.email,
    name: name ?? this.name,
    phone: phone ?? this.phone,
    avatarUrl: avatarUrl ?? this.avatarUrl,
    shippingAddresses: shippingAddresses ?? this.shippingAddresses,
    createdAt: createdAt ?? this.createdAt,
    isAdmin: isAdmin ?? this.isAdmin,
  );

  Map<String, dynamic> toMap() => {
    'id': id, 'email': email, 'name': name,
    'phone': phone, 'avatarUrl': avatarUrl,
    'shippingAddresses': shippingAddresses,
    'isAdmin': isAdmin,
    'createdAt': createdAt.toIso8601String(),
  };

  factory User.fromMap(Map<String, dynamic> map) => User(
    id: map['id'] ?? '',
    email: map['email'] ?? '',
    name: map['name'] ?? '',
    phone: map['phone'],
    avatarUrl: map['avatarUrl'],
    shippingAddresses: List<String>.from(map['shippingAddresses'] ?? []),
    isAdmin: map['isAdmin'] ?? false,
    createdAt: map['createdAt'] != null ? DateTime.parse(map['createdAt']) : null,
  );
}
