class FeedbackItem {
  final String category;
  final String title;
  final String description;
  final String userEmail;
  final DateTime createdAt;

  const FeedbackItem({
    required this.category,
    required this.title,
    required this.description,
    required this.userEmail,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'category': category,
    'title': title,
    'description': description,
    'userEmail': userEmail,
    'createdAt': createdAt.toIso8601String(),
  };
}
