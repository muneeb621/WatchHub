import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:watchhub/providers/auth_provider.dart';
import 'package:watchhub/screens/auth/login_screen.dart';
import 'package:watchhub/screens/auth/signup_screen.dart';
import 'package:watchhub/screens/auth/forgot_password_screen.dart';
import 'package:watchhub/screens/auth/onboarding_screen.dart';
import 'package:watchhub/screens/home/home_screen.dart';
import 'package:watchhub/screens/product/product_detail_screen.dart';
import 'package:watchhub/screens/cart/cart_screen.dart';
import 'package:watchhub/screens/profile/profile_screen.dart';
import 'package:watchhub/screens/profile/order_history_screen.dart';
import 'package:watchhub/screens/profile/manage_addresses_screen.dart';
import 'package:watchhub/screens/wishlist/wishlist_screen.dart';
import 'package:watchhub/screens/support/support_screen.dart';
import 'package:watchhub/screens/support/faq_screen.dart';
import 'package:watchhub/screens/search/search_screen.dart';
import 'package:watchhub/screens/admin/admin_dashboard.dart';
import 'package:watchhub/screens/admin/manage_products.dart';
import 'package:watchhub/screens/admin/manage_users.dart';
import 'package:watchhub/screens/admin/manage_orders.dart';
import 'package:watchhub/screens/admin/manage_reviews.dart';
import 'package:watchhub/models/watch.dart';

class AppRoutes {
  static const String login = '/login';
  static const String signup = '/signup';
  static const String onboarding = '/onboarding';
  static const String forgotPassword = '/forgot-password';
  static const String home = '/home';
  static const String productDetail = '/product-detail';
  static const String cart = '/cart';
  static const String profile = '/profile';
  static const String orderHistory = '/order-history';
  static const String wishlist = '/wishlist';
  static const String support = '/support';
  static const String faq = '/faq';
  static const String search = '/search';
  static const String adminDashboard = '/admin';
  static const String adminProducts = '/admin/products';
  static const String adminUsers = '/admin/users';
  static const String adminOrders = '/admin/orders';
  static const String adminReviews = '/admin/reviews';

  static const Set<String> _protectedRoutes = {
    home, profile, orderHistory, wishlist,
    adminDashboard, adminProducts, adminUsers,
    adminOrders, adminReviews,
    '/track-order', '/addresses',
  };

  static const Set<String> _guestAllowedRoutes = {
    cart,
  };

  static Map<String, WidgetBuilder> get routes {
    return {
      onboarding: (_) => const OnboardingScreen(),
      login: (_) => const LoginScreen(),
      signup: (_) => const SignupScreen(),
      forgotPassword: (_) => const ForgotPasswordScreen(),
      home: (_) => const HomeScreen(),
      cart: (_) => const CartScreen(),
      profile: (_) => const ProfileScreen(),
      orderHistory: (_) => const OrderHistoryScreen(),
      '/track-order': (_) => const OrderHistoryScreen(trackOnly: true),
      '/addresses': (_) => const ManageAddressesScreen(),
      wishlist: (_) => const WishlistScreen(),
      support: (_) => const SupportScreen(),
      faq: (_) => const FaqScreen(),
      search: (_) => const SearchScreen(),
      adminDashboard: (_) => const AdminDashboard(),
      adminProducts: (_) => const ManageProductsScreen(),
      adminUsers: (_) => const ManageUsersScreen(),
      adminOrders: (_) => const ManageOrdersScreen(),
      adminReviews: (_) => const ManageReviewsScreen(),
    };
  }

  static Route<dynamic> generateRoute(RouteSettings settings) {
    if (settings.name == productDetail) {
      final watch = settings.arguments as Watch;
      return _CustomPageRoute(
        builder: (_) => ProductDetailScreen(watch: watch),
        settings: settings,
      );
    }
    return _CustomPageRoute(
      settings: settings,
      builder: (context) {
        if (_protectedRoutes.contains(settings.name) && !_guestAllowedRoutes.contains(settings.name)) {
          final auth = context.watch<AuthProvider>();
          if (!auth.isLoggedIn) {
            return const LoginScreen();
          }
          if (settings.name!.startsWith('/admin/') || settings.name == adminDashboard) {
            if (!auth.isAdmin) {
              return const HomeScreen();
            }
          }
        }
        final routeBuilder = routes[settings.name];
        if (routeBuilder != null) {
          return routeBuilder(context);
        }
        return const LoginScreen();
      },
    );
  }
}

class _CustomPageRoute extends PageRouteBuilder {
  final WidgetBuilder builder;

  @override
  final RouteSettings settings;

  _CustomPageRoute({required this.builder, required this.settings})
    : super(
        settings: settings,
        pageBuilder: (context, animation, secondaryAnimation) => builder(context),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const curve = Curves.easeInOutCubic;
          final slideTween = Tween(begin: const Offset(0.3, 0.0), end: Offset.zero).chain(CurveTween(curve: curve));
          final fadeTween = Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: curve));
          final scaleTween = Tween(begin: 0.95, end: 1.0).chain(CurveTween(curve: curve));
          return SlideTransition(
            position: animation.drive(slideTween),
            child: FadeTransition(
              opacity: animation.drive(fadeTween),
              child: ScaleTransition(
                scale: animation.drive(scaleTween),
                child: child,
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 350),
        reverseTransitionDuration: const Duration(milliseconds: 250),
      );
}
