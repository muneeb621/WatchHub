import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFFFFD700);
  static const Color accentColor = Color(0xFFFFD700);
  static const Color accentLight = Color(0xFFFFED4A);
  static const Color accentDark = Color(0xFFDAA520);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFFB0B0B0);
  static const Color cardColor = Color(0xFF1E1E1E);
  static const Color backgroundColor = Color(0xFF121212);
  static const Color errorColor = Color(0xFFCF6679);
  static const Color successColor = Color(0xFF4CAF50);

  // --- Dark Theme ---
  static const Color darkPrimary = Color(0xFF0A0A1A);
  static const Color darkCard = Color(0xFF1A1A2E);
  static const Color darkBg = Color(0xFF0D0D1A);
  static const Color darkSurface = Color(0x801A1A2E);
  static const Color darkTextPrimary = Colors.white;
  static const Color darkTextSecondary = Color(0xFFB0B0B0);

  // --- Light Theme ---
  static const Color lightPrimary = Color(0xFFFAFAF5);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightBg = Color(0xFFF5F5F0);
  static const Color lightSurface = Color(0xB3FFFFFF);
  static const Color lightTextPrimary = Color(0xFF1A1A2E);
  static const Color lightTextSecondary = Color(0xFF666666);

  // --- Gold Gradient ---
  static const LinearGradient goldGradient = LinearGradient(
    colors: [accentLight, accentColor, accentDark],
    stops: [0.0, 0.5, 1.0],
  );

  static const List<Color> goldColors = [accentLight, accentColor, accentDark];

  // --- Neon Glow for Dark Theme ---
  static List<BoxShadow> get neonGlow => [
    BoxShadow(
      color: accentColor.withValues(alpha: 0.3),
      blurRadius: 12,
      spreadRadius: 1,
    ),
    BoxShadow(
      color: accentColor.withValues(alpha: 0.15),
      blurRadius: 24,
      spreadRadius: 2,
    ),
  ];

  static List<BoxShadow> get neonGlowSmall => [
    BoxShadow(
      color: accentColor.withValues(alpha: 0.25),
      blurRadius: 8,
      spreadRadius: 0,
    ),
  ];

  // --- Glass Card Style ---
  static BoxDecoration glassCardDark = BoxDecoration(
    color: darkSurface,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
    boxShadow: [
      BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 16, offset: const Offset(0, 4)),
    ],
  );

  static BoxDecoration glassCardLight = BoxDecoration(
    color: lightSurface,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: Colors.white.withValues(alpha: 0.6)),
    boxShadow: [
      BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 16, offset: const Offset(0, 4)),
    ],
  );

  // --- Button Style with Gradient ---
  static ButtonStyle goldButtonStyle({
    double borderRadius = 10,
    EdgeInsetsGeometry padding = const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
  }) {
    return ElevatedButton.styleFrom(
      foregroundColor: Colors.black,
      padding: padding,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(borderRadius)),
      textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 0.5),
      shadowColor: accentColor.withValues(alpha: 0.4),
      elevation: 6,
    ).copyWith(
      backgroundColor: WidgetStateProperty.resolveWith((_) => null),
      overlayColor: WidgetStateProperty.all(accentColor.withValues(alpha: 0.15)),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: darkBg,
      colorScheme: const ColorScheme.dark(
        primary: accentColor,
        secondary: accentColor,
        surface: darkCard,
        error: errorColor,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: accentColor,
        elevation: 0,
        centerTitle: true,
        scrolledUnderElevation: 0,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(style: goldButtonStyle()),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0x1AFFFFFF),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0x33FFFFFF)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: accentColor, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: darkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xCC0A0A1A),
        selectedItemColor: accentColor,
        unselectedItemColor: darkTextSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      textTheme: TextTheme(
        headlineLarge: GoogleFonts.playfairDisplay(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.white),
        headlineMedium: GoogleFonts.playfairDisplay(fontSize: 24, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: -0.5),
        titleLarge: GoogleFonts.playfairDisplay(fontSize: 18, fontWeight: FontWeight.w600, color: accentColor, letterSpacing: 0.3),
        titleMedium: GoogleFonts.playfairDisplay(fontSize: 16, fontWeight: FontWeight.w500, color: accentColor),
        bodyLarge: GoogleFonts.inter(fontSize: 16, color: Colors.white),
        bodyMedium: GoogleFonts.inter(fontSize: 14, color: Colors.white70),
        labelLarge: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.5),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0x1AFFFFFF),
        selectedColor: accentColor.withValues(alpha: 0.3),
        labelStyle: const TextStyle(color: Colors.white, fontSize: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(color: Colors.white.withValues(alpha: 0.08), thickness: 0.5),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: darkCard,
        contentTextStyle: const TextStyle(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: darkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: lightBg,
      colorScheme: const ColorScheme.light(
        primary: Color(0xFF1A1A2E),
        secondary: accentColor,
        surface: lightCard,
        error: errorColor,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: Color(0xFF1A1A2E),
        elevation: 0,
        centerTitle: true,
        scrolledUnderElevation: 0,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(style: goldButtonStyle()),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0x08000000),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0x1A000000)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: accentColor, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: lightCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xF2FFFFFF),
        selectedItemColor: Color(0xFF1A1A2E),
        unselectedItemColor: lightTextSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      textTheme: TextTheme(
        headlineLarge: GoogleFonts.playfairDisplay(fontSize: 28, fontWeight: FontWeight.w700, color: const Color(0xFF1A1A2E)),
        headlineMedium: GoogleFonts.playfairDisplay(fontSize: 24, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E), letterSpacing: -0.5),
        titleLarge: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E)),
        titleMedium: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w500, color: const Color(0xFF1A1A2E)),
        bodyLarge: GoogleFonts.inter(fontSize: 16, color: const Color(0xFF1A1A2E)),
        bodyMedium: GoogleFonts.inter(fontSize: 14, color: lightTextSecondary),
        labelLarge: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E), letterSpacing: 0.5),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0x0A000000),
        selectedColor: accentColor.withValues(alpha: 0.3),
        labelStyle: const TextStyle(color: Color(0xFF1A1A2E), fontSize: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(color: Colors.black.withValues(alpha: 0.06), thickness: 0.5),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: lightCard,
        contentTextStyle: const TextStyle(color: Color(0xFF1A1A2E)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: lightCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }
}

// --- Gold Gradient Button Widget ---
class GoldButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final double borderRadius;
  final EdgeInsetsGeometry padding;

  const GoldButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.borderRadius = 10,
    this.padding = const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: AppTheme.goldGradient,
        boxShadow: AppTheme.neonGlowSmall,
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          foregroundColor: Colors.black,
          padding: padding,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(borderRadius)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 0.5),
        ).copyWith(
          overlayColor: WidgetStateProperty.all(Colors.black.withValues(alpha: 0.08)),
        ),
        child: icon != null
            ? Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(icon, size: 20),
                const SizedBox(width: 8),
                Text(label),
              ])
            : Text(label),
      ),
    );
  }
}

// --- Glass Card Widget ---
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.borderRadius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: margin ?? const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: isDark ? AppTheme.glassCardDark : AppTheme.glassCardLight,
      clipBehavior: Clip.antiAlias,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Padding(
            padding: padding ?? const EdgeInsets.all(16),
            child: child,
          ),
        ),
      ),
    );
  }
}
