class AppConstants {
  static const String appName = 'WatchHub';
  static const String apiBaseUrl = 'https://api.watchhub.com/v1';
  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;
  static const double defaultPadding = 16.0;
  static const double cardRadius = 12.0;
  static const double buttonRadius = 8.0;

  static const List<String> watchBrands = [
    'Rolex', 'Omega', 'Tag Heuer', 'Seiko', 'Citizen',
    'Casio', 'Fossil', 'Timex', 'Tissot', 'Longines',
  ];

  static const List<String> watchTypes = [
    'Analog', 'Digital', 'Automatic', 'Chronograph',
    'Diver', 'Dress', 'Sports', 'Smartwatch',
  ];

  static const List<String> priceRanges = [
    'Under \$500', '\$500 - \$1000', '\$1000 - \$5000',
    '\$5000 - \$10000', 'Above \$10000',
  ];

  static const List<String> sortOptions = [
    'Newest', 'Price: Low to High', 'Price: High to Low',
    'Popularity', 'Rating',
  ];
}
