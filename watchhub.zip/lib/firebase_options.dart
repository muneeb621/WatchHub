import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    if (defaultTargetPlatform == TargetPlatform.android) return android;
    if (defaultTargetPlatform == TargetPlatform.iOS) return ios;
    if (defaultTargetPlatform == TargetPlatform.macOS) return macos;
    if (defaultTargetPlatform == TargetPlatform.windows) return windows;
    if (defaultTargetPlatform == TargetPlatform.linux) return linux;
    throw UnsupportedError('Unsupported platform');
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:android:419596a2f6f1eac1638c59',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:ios:0000000000000000000000',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
    iosBundleId: 'com.watchhub.watchhub',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:ios:0000000000000000000000',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
    iosBundleId: 'com.watchhub.watchhub',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:web:419596a2f6f1eac1638c59',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
    authDomain: 'watchhub-ee1be.firebaseapp.com',
    measurementId: 'G-XXXXXXXX',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:web:419596a2f6f1eac1638c59',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
    authDomain: 'watchhub-ee1be.firebaseapp.com',
  );

  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: 'AIzaSyCENn7w1wVKeotUzJ4j5ZXSsU0DDITygBI',
    appId: '1:451236466076:web:419596a2f6f1eac1638c59',
    messagingSenderId: '451236466076',
    projectId: 'watchhub-ee1be',
    storageBucket: 'watchhub-ee1be.firebasestorage.app',
    authDomain: 'watchhub-ee1be.firebaseapp.com',
  );
}
